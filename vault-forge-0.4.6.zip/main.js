var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/utils/files.ts
async function ensureFolder(app, folderPath) {
  const normalised = (0, import_obsidian.normalizePath)(folderPath);
  if (!normalised || normalised === ".")
    return;
  const existing = app.vault.getAbstractFileByPath(normalised);
  if (existing instanceof import_obsidian.TFolder)
    return;
  const parts = normalised.split("/");
  let current = "";
  for (const part of parts) {
    current = current ? `${current}/${part}` : part;
    const node = app.vault.getAbstractFileByPath(current);
    if (!node) {
      try {
        await app.vault.createFolder(current);
      } catch (e) {
      }
    }
  }
}
function getMarkdownFiles(app, rootFolder) {
  const files = app.vault.getMarkdownFiles();
  if (!rootFolder)
    return files.filter((f) => !isHiddenPath(f.path));
  const prefix = (0, import_obsidian.normalizePath)(rootFolder).toLowerCase() + "/";
  return files.filter(
    (f) => f.path.toLowerCase().startsWith(prefix) && !isHiddenPath(f.path)
  );
}
function getFile(app, path) {
  const file = app.vault.getAbstractFileByPath((0, import_obsidian.normalizePath)(path));
  return file instanceof import_obsidian.TFile ? file : null;
}
function resolveTargets(app, target, targetPattern) {
  const results = [];
  if (target) {
    const file = getFile(app, target);
    if (file) {
      results.push(file);
    } else {
      console.warn(`[VaultForge] target not found: ${target}`);
    }
  }
  if (targetPattern) {
    const allFiles = getMarkdownFiles(app);
    for (const file of allFiles) {
      if (matchesGlob(file.path, targetPattern)) {
        results.push(file);
      }
    }
  }
  const seen = /* @__PURE__ */ new Set();
  return results.filter((f) => {
    if (seen.has(f.path))
      return false;
    seen.add(f.path);
    return true;
  });
}
function isExempt(path, exemptPaths) {
  if (!exemptPaths.length)
    return false;
  const normalised = (0, import_obsidian.normalizePath)(path).toLowerCase();
  return exemptPaths.some((p) => {
    const prefix = (0, import_obsidian.normalizePath)(p).toLowerCase();
    return normalised.startsWith(prefix + "/") || normalised === prefix;
  });
}
function matchesGlob(path, pattern) {
  const normPath = (0, import_obsidian.normalizePath)(path).toLowerCase();
  const normPattern = (0, import_obsidian.normalizePath)(pattern).toLowerCase();
  const regexStr = globToRegex(normPattern);
  try {
    return new RegExp(regexStr).test(normPath);
  } catch (e) {
    return false;
  }
}
function globToRegex(pattern) {
  const escaped = pattern.replace(/[.+^${}()|[\]\\]/g, "\\$&");
  const regexBody = escaped.replace(/\*\*\//g, "(.+/)?").replace(/\*\*/g, ".*").replace(/\*/g, "[^/]*");
  return `^${regexBody}$`;
}
function isHiddenPath(path) {
  return path.split("/").some((segment) => segment.startsWith("."));
}
function safeTimestamp() {
  return (/* @__PURE__ */ new Date()).toISOString().replace(/T/, "_").replace(/:/g, "").substring(0, 15);
}
function todayString() {
  return (/* @__PURE__ */ new Date()).toISOString().substring(0, 10);
}
function buildExemptList(schemaExemptPaths, vaultForgeFolder) {
  return [...schemaExemptPaths, vaultForgeFolder];
}
var import_obsidian;
var init_files = __esm({
  "src/utils/files.ts"() {
    import_obsidian = require("obsidian");
  }
});

// src/utils/frontmatter.ts
var frontmatter_exports = {};
__export(frontmatter_exports, {
  backupNote: () => backupNote,
  getFmString: () => getFmString,
  isFieldPresent: () => isFieldPresent,
  parseNote: () => parseNote,
  readNote: () => readNote,
  sortFrontmatterFields: () => sortFrontmatterFields,
  writeNote: () => writeNote
});
async function readNote(app, file) {
  let raw;
  try {
    raw = await app.vault.read(file);
  } catch (e) {
    console.warn(`[VaultForge] Could not read file: ${file.path}`, e);
    return null;
  }
  return parseNote(raw, file);
}
function parseNote(raw, file) {
  var _a;
  const match = raw.match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n?([\s\S]*)$/);
  if (!match) {
    return {
      frontmatter: {},
      body: raw,
      hasFrontmatter: false,
      file
    };
  }
  const fmText = match[1];
  const body = (_a = match[2]) != null ? _a : "";
  let frontmatter = {};
  try {
    const parsed = (0, import_obsidian5.parseYaml)(fmText);
    if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
      frontmatter = parsed;
    }
  } catch (e) {
    console.warn(`[VaultForge] Could not parse YAML in: ${file.path}`, e);
  }
  return {
    frontmatter,
    body,
    hasFrontmatter: true,
    file
  };
}
async function writeNote(app, note) {
  const sorted = sortFrontmatterFields(note.frontmatter);
  const yaml = (0, import_obsidian5.stringifyYaml)(sorted).trimEnd();
  const newContent = `---
${yaml}
---
${note.body}`;
  await app.vault.modify(note.file, newContent);
}
async function backupNote(app, file, backupFolder) {
  await ensureFolder(app, backupFolder);
  const timestamp = (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-").replace("T", "_").substring(0, 19);
  const safeName = file.path.replace(/\//g, "_");
  const backupPath = (0, import_obsidian5.normalizePath)(
    `${backupFolder}/${safeName}.${timestamp}.bak`
  );
  try {
    const content = await app.vault.read(file);
    await app.vault.create(backupPath, content);
    return backupPath;
  } catch (e) {
    console.warn(`[VaultForge] Could not create backup for ${file.path}:`, e);
    return null;
  }
}
function sortFrontmatterFields(frontmatter) {
  const result = {};
  for (const field of PREFERRED_FIELD_ORDER) {
    if (Object.prototype.hasOwnProperty.call(frontmatter, field)) {
      result[field] = frontmatter[field];
    }
  }
  const remaining = Object.keys(frontmatter).filter((k) => !PREFERRED_FIELD_ORDER.includes(k)).sort();
  for (const key of remaining) {
    result[key] = frontmatter[key];
  }
  return result;
}
function isFieldPresent(frontmatter, fieldName) {
  if (!Object.prototype.hasOwnProperty.call(frontmatter, fieldName)) {
    return false;
  }
  const value = frontmatter[fieldName];
  if (value === null || value === void 0)
    return false;
  if (typeof value === "string")
    return value.trim().length > 0;
  if (Array.isArray(value))
    return value.length > 0;
  return true;
}
function getFmString(frontmatter, fieldName) {
  const value = frontmatter[fieldName];
  if (value === null || value === void 0)
    return "";
  if (Array.isArray(value)) {
    return value.filter((v) => v !== null && v !== void 0).map((v) => String(v)).join("; ");
  }
  return String(value);
}
var import_obsidian5, PREFERRED_FIELD_ORDER;
var init_frontmatter = __esm({
  "src/utils/frontmatter.ts"() {
    import_obsidian5 = require("obsidian");
    init_files();
    PREFERRED_FIELD_ORDER = [
      "type",
      "kind",
      "domain",
      "status",
      "patterns",
      "tags",
      "created",
      "updated",
      "review_by",
      "ai_private",
      "ai_open_questions",
      "source",
      "supersedes",
      "superseded_by",
      "version",
      "review_cycle"
    ];
  }
});

// src/main.ts
var main_exports = {};
__export(main_exports, {
  default: () => VaultForgePlugin
});
module.exports = __toCommonJS(main_exports);
var import_obsidian17 = require("obsidian");

// src/settings.ts
var DEFAULT_SETTINGS = {
  // System paths
  systemFolder: "System",
  vaultForgeFolder: "System/VaultForge",
  schemaNoteFolder: "System/Registry",
  schemaNoteFile: "schema.md",
  exportsFolder: "System/Exports",
  patchesFolder: "System/VaultForge/Patches",
  lintRunsFolder: "System/Exports/LintReports",
  inboxFolder: "System/Inbox",
  patternsFolder: "System/Patterns",
  // Patch
  patchBackupEnabled: true,
  patchGenerateManifest: true,
  patchDefaultFile: "System/VaultForge/Patches/vault-patch.md",
  patchAutoLintAfterApply: true,
  patchAutoMaintenanceAfterApply: false,
  // Lint
  lintStrictMode: false,
  lintRunRetentionCount: 20,
  lintFileLinks: false,
  // Maintenance
  backupRetentionDays: 14,
  inboxRetentionDays: 14,
  lintHistoryRetentionDays: 14,
  lintHistoryMaxEntries: 20,
  patchReportRetentionCount: 20
};

// src/settings-tab.ts
var import_obsidian3 = require("obsidian");

// src/docs.ts
var import_obsidian2 = require("obsidian");

// src/vault-paths.ts
function getVaultPaths(settings) {
  const s = settings;
  const schemaMd = `${s.schemaNoteFolder}/${s.schemaNoteFile}`;
  const vaultForge = s.vaultForgeFolder;
  return {
    // Schema
    schemaMd,
    // VaultForge system
    vaultForge,
    patches: s.patchesFolder,
    patchApplied: `${s.patchesFolder}/Applied`,
    patchBackups: `${s.patchesFolder}/Backups`,
    patchReports: `${s.patchesFolder}/Reports`,
    indexDefinitions: `${vaultForge}/Indexes`,
    // Exports
    exports: s.exportsFolder,
    lintReportJson: `${s.exportsFolder}/lint-report.json`,
    lintHistoryJson: `${s.exportsFolder}/lint-history.json`,
    vaultMeta: `${s.exportsFolder}/vault-meta.json`,
    // Human-readable lint report notes
    lintRuns: s.lintRunsFolder,
    // Vault structure
    patterns: s.patternsFolder,
    templates: `${s.systemFolder}/Templates`,
    inbox: s.inboxFolder,
    dashboards: `${s.systemFolder}/Dashboards`,
    // Patch
    patchFile: s.patchDefaultFile
  };
}

// src/docs.ts
init_files();

// vault-forge-docs:vault-forge:docs
var vault_forge_docs_default = {
  "0.START-HERE": `Vault Forge is a schema-driven governance plugin for Obsidian.

It helps keep long-lived vaults structurally healthy through schema validation, linting, patch operations, tag normalization, frontmatter normalization, repair workflows, and maintenance routines.

# Who this is for

Vault Forge is for people who treat their Obsidian vault as a long-term knowledge system rather than a loose collection of notes.

It is useful when you want:

- consistent frontmatter
- predictable tags
- schema validation
- safe bulk edits
- patch history
- repeatable maintenance
- operational visibility into vault structure

# What Vault Forge is not

Vault Forge is not an AI assistant, template engine, or note-taking methodology.

It does not decide what your vault means.

It enforces the structure you define.

# How Vault Forge works

Vault Forge uses:

- schema notes to define expected structure
- linting to detect inconsistencies
- patches to apply explicit vault changes
- normalization routines to keep metadata consistent
- repair workflows to safely resolve problems

Most workflows follow this pattern:

1. Define structure
2. Validate the vault
3. Review problems
4. Generate or apply fixes
5. Re-run validation

# First setup checklist

1. Confirm your Vault Forge folder in settings.
2. Create or choose a schema note.
3. Click **Load from Schema** in Vault Forge settings.
4. Run **Vault Forge: Validate Schema**.
5. Run **Vault Forge: Run Vault Lint**.
6. Create a patch note at your configured patch path.
7. Run **Vault Forge: Apply Vault Patch**.

# Current configured locations

| Purpose | Path |
|---|---|
| Vault Forge folder | \`{{vaultForge}}\` |
| Docs | \`{{docsFolder}}\` |
| Examples | \`{{examplesFolder}}\` |
| Schema note | \`{{schemaFile}}\` |
| Patch note | \`{{patchFile}}\` |
| Patches folder | \`{{patchesFolder}}\` |
| Exports folder | \`{{exportsFolder}}\` |

# Recommended reading order

1. [[1.Installation|Installation]]
2. [[2.Vault-Structure|Vault-Structure]]
3. [[3.Schema|Schema]]
4. [[4.Linting|Linting]]
5. [[5.Patches|Patches]]
6. [[6.Commands|Commands]]
7. [[7.Settings|Settings]]
8. [[8.Troubleshooting|Troubleshooting]]`,
  "1.Installation": `# Installation

## Manual Installation

1. Copy the release assets into your Obsidian plugin folder:

\`\`\`text
.obsidian/plugins/vault-forge/
\u251C\u2500\u2500 main.js
\u251C\u2500\u2500 manifest.json
\u2514\u2500\u2500 versions.json
\`\`\`

2. Refresh **Community plugins**
3. Then enable **Vault Forge**

## Community Plugins

**Not yet available**

# Updating

## Manual Update

Recommended update process:

1. Disable Vault Forge in Obsidian.
2. Replace \`main.js\`, \`manifest.json\`, and \`versions.json\`.
3. Re-enable Vault Forge.

Disabling the plugin before replacing files helps avoid stale loaded code during updates.

## Community Plugins

**Not yet available**

# iOS notes

On iOS, the \`.obsidian\` folder may be hidden by the Files app.

The most reliable approach is to install or update the plugin on desktop and allow Obsidian Sync or iCloud to transfer the plugin files.

Apps such as \`Taio\` may also help expose hidden folders.

# Verify installation

Open the command palette and search for:

\`\`\`text
Vault Forge
\`\`\`

You should see commands such as:

- Vault Forge: Run Vault Lint
- Vault Forge: Apply Vault Patch
- Vault Forge: Validate Schema
- Vault Forge: Install Documentation

# Documentation location

This documentation was installed into:

\`\`\`text
{{docsFolder}}
\`\`\`

Examples were installed into:

\`\`\`text
{{examplesFolder}}
\`\`\`

Continue with [[2.Vault-Structure|Vault-Structure]].`,
  "2.Vault-Structure": `Vault Forge works best when operational files live in a predictable location.

It does not require the folder to be named \`System/VaultForge\`. It uses the Vault Forge folder configured in settings.

# Current configured structure

\`\`\`text
{{vaultForge}}/
\u251C\u2500\u2500 Docs/
\u251C\u2500\u2500 Examples/
\u251C\u2500\u2500 Indexes/
\u2514\u2500\u2500 Patches/
    \u251C\u2500\u2500 vault-patch.md
    \u251C\u2500\u2500 Applied/
    \u251C\u2500\u2500 Backups/
    \u2514\u2500\u2500 Reports/
\`\`\`

# Folder meanings

| Folder | Purpose |
|---|---|
| \`{{docsFolder}}\` | Vault-native documentation |
| \`{{examplesFolder}}\` | Starter schema and patch examples |
| \`{{patchesFolder}}\` | Active patch note and patch history |
| \`{{patchesFolder}}/Applied\` | Archived applied patch notes |
| \`{{patchesFolder}}/Backups\` | File backups created before patch changes |
| \`{{patchesFolder}}/Reports\` | Patch reports and restore manifests |
| \`{{exportsFolder}}\` | Lint reports and export outputs |

# Why this structure exists

Vault Forge treats vault operations as first-class vault content.

Patch notes, reports, examples, and docs remain inside the vault so they are:

- searchable
- linkable
- syncable
- reviewable
- versionable

This keeps operational history visible instead of hidden inside plugin state.

# Recommended practices

Vault Forge works best when:

- patch files remain inside the configured patches folder
- reports and backups are retained
- schema notes live in stable locations
- operational folders are excluded from normal writing workflows

The exact folder layout is flexible, but consistency matters.

Continue with [[3.Schema|Schema]].`,
  "3.Schema": `Vault Forge validates notes against a schema note.

Current configured schema path:

\`\`\`text
{{schemaFile}}
\`\`\`

# What a schema does

A schema defines the expected structure of your vault.

It can describe:

- required frontmatter fields
- allowed field values
- tag rules
- validation severity
- normalization behavior
- patch workflow expectations

Vault Forge uses the schema during linting, repair workflows, normalization, and patch operations.

# Schema format

A schema is a markdown note containing normal frontmatter and a fenced YAML block.

The YAML block defines validation and operational rules.

# Required fields

Required fields define the frontmatter expected on normal notes.

Example:

\`\`\`yaml
required_fields:
  - name: type
    type: enum
    values: [reference, procedure, project]
    severity: error

  - name: status
    type: enum
    values: [draft, active, complete, archived]
    severity: error
\`\`\`

# Supported field types

Common field types include:

- \`enum\`
- \`list\`
- \`date\`
- \`boolean\`

# Severity

Severity controls how validation issues are reported.

| Severity | Meaning |
|---|---|
| \`error\` | Must be fixed |
| \`warning\` | Should be reviewed |
| \`info\` | Informational |

# Recommended approach

Start with a small schema.

Avoid attempting to model the entire vault immediately.

A good first schema usually defines:

- note type
- status
- core tags
- required metadata

Schemas can evolve over time as vault structure becomes more stable.

# Linting

Vault Forge uses schema rules during linting and repair workflows.

See:

\`\`\`text
[[4.Linting|Linting]]
\`\`\`

# Example schema

See:

\`\`\`text
{{examplesFolder}}/schema.md
\`\`\`

Continue with [[4.Linting|Linting]].`,
  "4.Linting": `Linting validates vault notes against the configured schema.

Run it from the command palette:

\`\`\`text
Vault Forge: Run Vault Lint
\`\`\`

# What lint checks

Vault Forge can validate:

- required frontmatter fields
- field types
- enum values
- date formats
- required tags
- tag namespace rules
- exempt paths

Linting helps detect structural drift before inconsistencies spread through the vault.

# Reports

Lint reports are written under:

\`\`\`text
{{exportsFolder}}
\`\`\`

Common outputs include:

- \`lint-report.json\`
- \`lint-history.json\`
- lint run notes

These reports provide operational visibility into vault health over time.

# Strict mode

Strict mode treats warnings as errors.

Use strict mode when your schema is mature.

Leave it disabled while designing or evolving a new schema.

# Repair workflow

Vault Forge keeps repair workflows explicit and reviewable.

Typical workflow:

1. Run **Vault Forge: Run Vault Lint**.
2. Review lint results.
3. Run **Vault Forge: Vault Repair**.
4. Review the generated patch.
5. Apply the patch.
6. Run lint again.

This avoids silent vault modifications and keeps repair operations auditable.

# Recommended approach

Run lint regularly while evolving vault structure.

Smaller, incremental fixes are easier to review and safer to apply than large corrective patch runs.

Continue with [[5.Patches|Patches]].`,
  "5.Patches": `Patches are explicit vault operations stored as markdown notes.

Current configured patch note:

\`\`\`text
{{patchFile}}
\`\`\`

# What patches do

Patches allow Vault Forge to apply structured, reviewable vault changes.

Typical uses include:

- fixing metadata
- normalizing tags
- reorganizing notes
- repairing lint violations
- applying repeatable maintenance operations

Vault Forge keeps patch operations explicit instead of silently modifying vault content.

# Patch note format

A patch note is a normal vault note containing a fenced YAML block.

Example:

\`\`\`\`md
---
type: procedure
status: draft
tags:
  - tool/vault-forge
created: {{today}}
updated: {{today}}
ai_private: false
review_cycle: never
---
\`\`\`

# Vault Patch

\`\`\`yaml
meta:
  description: Activate Home note

operations:
  - op: set_field
    target: "Home.md"
    field: status
    value: active
\`\`\`

Vault Forge reads only the fenced YAML block for patch operations. The rest of the note is for human context and review.

# Patch lifecycle

Typical workflow:

1. Edit the active patch note.
2. Run **Vault Forge: Apply Vault Patch**.
3. Review the dry-run confirmation.
4. Confirm apply.
5. Vault Forge writes backups, reports, and archive copies.
6. Re-run linting if needed.

Vault Forge separates patch generation from patch execution so changes remain reviewable and auditable.

# Patch folders

| Folder | Purpose |
|---|---|
| \`{{patchesFolder}}\` | Active patch note |
| \`{{patchesFolder}}/Applied\` | Archived applied patch notes |
| \`{{patchesFolder}}/Backups\` | Backups created before changes |
| \`{{patchesFolder}}/Reports\` | Reports and restore manifests |

# Targeting files

Most operations require either \`target\` or \`target_pattern\`.

| Field | Purpose |
|---|---|
| \`target\` | A single markdown file path |
| \`target_pattern\` | A glob-style pattern matching one or more markdown files |

Examples:

\`\`\`yaml
operations:
  - op: set_field
    target: "Home.md"
    field: status
    value: active
\`\`\`

\`\`\`yaml
operations:
  - op: normalize_tags
    target_pattern: "Projects/**/*.md"
\`\`\`

# Operation index

| Operation | Purpose |
|---|---|
| \`set_field\` | Set or update a frontmatter field |
| \`remove_field\` | Remove a frontmatter field |
| \`add_tag\` | Add a tag to frontmatter |
| \`remove_tag\` | Remove a tag from frontmatter |
| \`replace_tag\` | Replace one tag with another |
| \`normalize_tags\` | Sort and deduplicate tags |
| \`compute_field\` | Compute a frontmatter value from file metadata or activity |
| \`sort_frontmatter\` | Reorder frontmatter fields into the canonical order |
| \`move_note\` | Move a note from one folder tree to another |

# Supported operations

## \`set_field\`

Sets a frontmatter field to a literal value.

\`\`\`yaml
operations:
  - op: set_field
    target: "Home.md"
    field: status
    value: active
\`\`\`

Use \`only_if_missing\` to avoid overwriting an existing value.

\`\`\`yaml
operations:
  - op: set_field
    target: "Home.md"
    field: status
    value: active
    only_if_missing: true
\`\`\`

### Derived values

\`set_field\` can also derive a value from the file path.

Supported \`value_from\` values:

| Value | Result |
|---|---|
| \`filename\` | File name with extension |
| \`basename\` | File name without \`.md\` |
| \`folder\` | Immediate parent folder |
| \`parent_folder\` | Folder above the immediate parent |
| \`path\` | A specific path segment |

Example:

\`\`\`yaml
operations:
  - op: set_field
    target_pattern: "Projects/**/*.md"
    field: project
    value_from: folder
\`\`\`

For \`value_from: path\`, provide \`path_segment_index\`.

\`\`\`yaml
operations:
  - op: set_field
    target_pattern: "Projects/**/*.md"
    field: area
    value_from: path
    path_segment_index: 0
\`\`\`

Derived values may also use:

| Field | Purpose |
|---|---|
| \`trim_prefix\` | Remove text from the beginning of the derived value |
| \`trim_suffix\` | Remove text from the end of the derived value |
| \`lowercase\` | Convert the derived value to lowercase |
| \`uppercase\` | Convert the derived value to uppercase |

Example:

\`\`\`yaml
operations:
  - op: set_field
    target_pattern: "Projects/**/*.md"
    field: project
    value_from: basename
    trim_prefix: "Project - "
    lowercase: true
\`\`\`

## \`remove_field\`

Removes a frontmatter field.

\`\`\`yaml
operations:
  - op: remove_field
    target: "Home.md"
    field: old_field
\`\`\`

## \`add_tag\`

Adds a tag if it is not already present.

\`\`\`yaml
operations:
  - op: add_tag
    target: "Home.md"
    tag: topic/home
\`\`\`

## \`remove_tag\`

Removes a tag if present.

\`\`\`yaml
operations:
  - op: remove_tag
    target: "Home.md"
    tag: topic/old
\`\`\`

## \`replace_tag\`

Replaces one tag with another.

\`\`\`yaml
operations:
  - op: replace_tag
    target_pattern: "Projects/**/*.md"
    old_tag: topic/old
    new_tag: topic/new
\`\`\`

## \`normalize_tags\`

Sorts and deduplicates frontmatter tags.

\`\`\`yaml
operations:
  - op: normalize_tags
    target_pattern: "Projects/**/*.md"
\`\`\`

## \`compute_field\`

Computes a frontmatter field from file metadata or recent activity.

Supported strategies:

| Strategy | Purpose |
|---|---|
| \`file_created_time\` | Uses the file creation time |
| \`file_modified_time\` | Uses the file modified time |
| \`recent_activity\` | Sets a value when the file was modified within a recent window |

### File created time

\`\`\`yaml
operations:
  - op: compute_field
    target_pattern: "Notes/**/*.md"
    field: created
    strategy: file_created_time
    format: yyyy-MM-dd
    when_missing: true
\`\`\`

### File modified time

\`\`\`yaml
operations:
  - op: compute_field
    target_pattern: "Notes/**/*.md"
    field: updated
    strategy: file_modified_time
    format: yyyy-MM-dd
\`\`\`

### Recent activity

\`\`\`yaml
operations:
  - op: compute_field
    target_pattern: "Projects/**/*.md"
    field: status
    strategy: recent_activity
    days: 30
    value_if_true: active
    skip_if:
      - archived
      - complete
\`\`\`

## \`sort_frontmatter\`

Reorders frontmatter fields into Vault Forge's canonical order.

\`\`\`yaml
operations:
  - op: sort_frontmatter
    target_pattern: "Notes/**/*.md"
\`\`\`

## \`move_note\`

Moves a note from one folder tree to another while preserving the relative path under \`source_root\`.

\`\`\`yaml
operations:
  - op: move_note
    target: "Inbox/Example.md"
    source_root: "Inbox"
    destination_folder: "Notes"
\`\`\`

### Optional frontmatter merge

If \`frontmatter:\` is provided, the specified fields are merged into the note's existing frontmatter after moving. Fields in \`frontmatter:\` overwrite existing values. Fields not listed are left unchanged.

\`\`\`yaml
operations:
  - op: move_note
    target: "System/Inbox/Example.md"
    source_root: "System/Inbox"
    destination_folder: "Work/Projects"
    frontmatter:
      type: project
      status: active
\`\`\`

### Strip frontmatter

If \`strip_frontmatter: true\` is set, all frontmatter is removed during the move. The note body is preserved.

\`\`\`yaml
operations:
  - op: move_note
    target: "System/Inbox/Example.md"
    source_root: "System/Inbox"
    destination_folder: "Work/Projects"
    strip_frontmatter: true
\`\`\`

\`strip_frontmatter\` and \`frontmatter\` cannot be used together.

# Recommended approach

Start with small patches.

Review dry-run results before applying changes.

Review generated backups and reports before running large structural operations across the vault.

Smaller patch runs are easier to validate and safer to restore if needed.

# Safety

Keep backups enabled unless you have a specific reason to disable them.

Use **Vault Forge: Restore Patch Run** to restore files from a backup manifest created during a prior patch run.

Continue with [[6.Commands|Commands]].`,
  "6.Commands": `# Apply Vault Patch

Loads the configured patch note, performs a dry run, requests confirmation, then applies the patch operations.

Configured patch note:

\`\`\`text
{{patchFile}}
\`\`\`

Vault Forge writes backups, reports, and restore manifests during patch runs.

---

# Run Vault Lint

Validates vault notes against the configured schema.

Lint results are written under:

\`\`\`text
{{exportsFolder}}
\`\`\`

Linting helps detect structural drift, invalid metadata, missing fields, and tag inconsistencies.

---

# Validate Schema

Parses and validates the configured schema note.

This verifies schema syntax, field definitions, validation rules, and operational configuration before linting or patch operations use the schema.

---

# Normalize Tags

Sorts and deduplicates frontmatter tag lists.

Useful for:

- standardizing tag ordering
- removing duplicate tags
- improving Dataview consistency
- reducing metadata drift

---

# Normalize Frontmatter

Reorders frontmatter fields into Vault Forge's canonical order.

This helps maintain consistent metadata structure across the vault.

---

# Vault Maintenance

Runs maintenance routines for Vault Forge operational files.

Maintenance may include:

- backup retention cleanup
- patch report cleanup
- lint history cleanup
- inbox maintenance
- operational folder cleanup

---

# Vault Repair

Builds a repair patch from lint results.

The generated patch can then be reviewed, modified, and applied explicitly.

Typical workflow:

1. Run lint
2. Generate repair patch
3. Review the patch
4. Apply the patch
5. Run lint again

---

# Restore Patch Run

Uses a restore manifest to restore files from backups created during a prior patch run.

This command is intended for recovery from unwanted or incorrect patch operations.

---

# Rename Dataview Folder

Updates Dataview folder references after a folder rename.

This helps preserve Dataview queries and folder-based workflows after structural vault changes.

---

# Install Documentation

Installs Vault Forge documentation and examples into the configured Vault Forge folder.

Installed content includes:

- operational documentation
- schema examples
- patch examples
- onboarding notes`,
  "7.Settings": `Vault Forge settings are stored in the Obsidian plugin data store.

Change settings through the Obsidian settings UI.

# System Paths

System paths control where Vault Forge stores and reads operational files.

Important current paths:

| Setting | Current path |
|---|---|
| Vault Forge folder | \`{{vaultForge}}\` |
| Schema note | \`{{schemaFile}}\` |
| Exports folder | \`{{exportsFolder}}\` |
| Patches folder | \`{{patchesFolder}}\` |
| Inbox folder | \`{{inboxFolder}}\` |
| Patterns folder | \`{{patternsFolder}}\` |

Stable system paths help keep patch workflows, exports, reports, and repair operations predictable.

# Patch Settings

Patch settings control:

- backups
- restore manifests
- default patch note
- auto-lint behavior
- auto-maintenance behavior

Recommended defaults:

- backups enabled
- restore manifest enabled
- auto-lint after patch enabled
- auto-maintenance after patch disabled

Vault Forge favors explicit review over aggressive automation.

# Lint Settings

Lint settings control:

- strict mode
- lint history retention
- lint reporting behavior

Strict mode treats warnings as errors.

Use strict mode only after the schema becomes stable.

# Maintenance Settings

Maintenance settings control how long generated operational files are retained.

This includes:

- lint reports
- patch reports
- restore manifests
- maintenance history

Retention policies help prevent operational folders from growing indefinitely.

# Recommended approach

Keep operational paths stable once workflows are established.

Changing schema, patch, or export locations frequently can make historical operations harder to review and troubleshoot.

Continue with [[8.Troubleshooting|Troubleshooting]].`,
  "8.Troubleshooting": `# Patch file not found

Check Vault Forge settings and confirm the default patch file points to an existing note.

Configured patch path:

\`\`\`text
{{patchFile}}
\`\`\`

If the note does not exist, running **Vault Forge: Apply Vault Patch** can create a starter patch note.

# Patch note has no YAML block

Patch notes must contain a fenced YAML block with an \`operations\` list.

Example:

\`\`\`\`md
# Patch

\`\`\`yaml
operations: []
\`\`\`
\`\`\`\`

Vault Forge reads only the fenced YAML block when applying a patch.

# Patch operation failed

Review the generated patch report.

Patch reports are written to:

\`\`\`text
{{patchesFolder}}/Reports
\`\`\`

Common causes include:

- the target file does not exist
- the target pattern matched no files
- a required operation field is missing
- a destination file already exists
- the patch YAML is not valid

# Schema not loading

Check that:

- the schema note exists
- the schema setting points to the correct note
- the schema note has valid frontmatter
- the schema note has a fenced YAML block
- the YAML block is valid

Configured schema path:

\`\`\`text
{{schemaFile}}
\`\`\`

Run **Vault Forge: Validate Schema** to diagnose schema issues.

# Lint report not generated

Check that the exports folder exists or can be created:

\`\`\`text
{{exportsFolder}}
\`\`\`

Also confirm that the configured schema loads successfully. Linting depends on a valid schema.

# Reports not generated

Check that the reports folder exists or can be created:

\`\`\`text
{{patchesFolder}}/Reports
\`\`\`

Patch reports are generated during patch dry runs and applied patch runs.

# Backups not generated

Check that backups are enabled in Vault Forge settings.

Backups are written to:

\`\`\`text
{{patchesFolder}}/Backups
\`\`\`

Backups are only written when a patch operation changes a file.

# Restore manifest not generated

Check that both settings are enabled:

- backup before patch
- generate restore manifest

Restore manifests are written to:

\`\`\`text
{{patchesFolder}}/Reports
\`\`\`

A restore manifest is only created when a patch run modifies files and backups are available.

# Plugin update did not take effect

Disable Vault Forge before replacing plugin files, then re-enable it.

Files to replace:

\`\`\`text
main.js
manifest.json
versions.json
\`\`\`

If Obsidian still appears to use old code, restart Obsidian after replacing the files.

# Documentation did not update

**Vault Forge: Install Documentation** skips notes that already exist.

To reinstall a documentation note, delete or rename the existing note, then run **Vault Forge: Install Documentation** again.

Documentation folder:

\`\`\`text
{{docsFolder}}
\`\`\`

Examples folder:

\`\`\`text
{{examplesFolder}}
\`\`\`

# Recommended recovery order

When something fails, use this order:

1. Run **Vault Forge: Validate Schema**.
2. Run **Vault Forge: Run Vault Lint**.
3. Review the latest lint run note.
4. Review the latest patch report if a patch failed.
5. Confirm settings paths still point to the expected notes and folders.

Continue with [[0.START-HERE|START-HERE]].
`
};

// vault-forge-docs:vault-forge:examples
var vault_forge_examples_default = {
  "schema": `This is a small example schema. Copy the YAML block into your real schema note if you want a starter contract.

Configured schema location:

\`\`\`text
{{schemaFile}}
\`\`\`

# Schema

\`\`\`yaml
meta:
  author: vault
  schemaRef: "{{schemaFile}}"

required_fields:
  - name: type
    type: enum
    values:
      - reference
      - procedure
      - project
      - concept
    severity: error

  - name: status
    type: enum
    values: [draft, active, complete, archived]
    severity: error

  - name: tags
    type: list
    min_items: 1
    severity: error

  - name: created
    type: date
    format: "yyyy-MM-dd"
    severity: error

  - name: updated
    type: date
    format: "yyyy-MM-dd"
    severity: warning

  - name: ai_private
    type: boolean
    severity: warning

  - name: review_cycle
    type: enum
    values: [1, 3, 6, 12, never]
    severity: error

optional_fields: []

inline_fields:
  - source
  - version
  - schema_version
  - errors
  - warnings

tag_rules:
  require_namespace: true
  unknown_tags: warning
  severity: warning
  allowed_namespaces:
    - meta
    - skill
    - tool
    - topic

exempt_paths: []
\`\`\`
`,
  "vault-patch": `This is an example patch note.

Copy this structure to:

\`\`\`text
{{patchFile}}
\`\`\`

# Patch

\`\`\`yaml
meta:
  description: Activate Home note

operations:
  - op: set_field
    target: "Home.md"
    field: status
    value: active

  - op: add_tag
    target: "Home.md"
    tag: topic/home

  - op: normalize_tags
    target_pattern: "Projects/**/*.md"

  - op: sort_frontmatter
    target_pattern: "Notes/**/*.md"
\`\`\`

# Notes

Vault Forge reads only the fenced YAML block for operations. The rest of this note is for humans.
`
};

// src/docs.ts
function interpolate(template, ctx) {
  return template.replace(/\{\{(\w+)\}\}/g, (_, key) => {
    var _a;
    return (_a = ctx[key]) != null ? _a : `{{${key}}}`;
  });
}
async function installVaultForgeDocumentation(app, settings) {
  const paths = getVaultPaths(settings);
  const today = todayString();
  const ctx = {
    today,
    vaultForge: paths.vaultForge,
    docsFolder: `${paths.vaultForge}/Docs`,
    examplesFolder: `${paths.vaultForge}/Examples`,
    patchesFolder: paths.patches,
    patchFile: paths.patchFile,
    schemaFile: paths.schemaMd,
    exportsFolder: paths.exports,
    inboxFolder: paths.inbox,
    patternsFolder: paths.patterns
  };
  await ensureFolder(app, ctx.docsFolder);
  await ensureFolder(app, ctx.examplesFolder);
  const docs = buildDocList(ctx);
  let written = 0;
  let skipped = 0;
  for (const doc of docs) {
    const path = (0, import_obsidian2.normalizePath)(doc.path);
    const existing = app.vault.getAbstractFileByPath(path);
    if (existing instanceof import_obsidian2.TFile) {
      skipped++;
      continue;
    }
    const folder = path.includes("/") ? path.substring(0, path.lastIndexOf("/")) : "";
    if (folder)
      await ensureFolder(app, folder);
    await app.vault.create(path, doc.content);
    written++;
  }
  new import_obsidian2.Notice(
    `Vault Forge docs installed: ${written} written, ${skipped} already existed.`,
    6e3
  );
}
function buildDocList(ctx) {
  const docs = [
    ...Object.entries(vault_forge_docs_default).map(([key, raw]) => ({
      relativePath: `Docs/${key}.md`,
      raw,
      type: "reference",
      tags: inferTags(key, "docs")
    })),
    ...Object.entries(vault_forge_examples_default).map(([key, raw]) => ({
      relativePath: `Examples/${key}.md`,
      raw,
      type: inferType(key),
      tags: inferTags(key, "examples")
    }))
  ];
  return docs.map(({ relativePath, raw, type, tags }) => {
    const body = interpolate(raw, ctx);
    const frontmatter = [
      "---",
      `type: ${type}`,
      "status: active",
      "tags:",
      ...tags.map((t) => `  - ${t}`),
      `created: ${ctx.today}`,
      `updated: ${ctx.today}`,
      "ai_private: false",
      "review_cycle: never",
      "---",
      ""
    ].join("\n");
    return {
      path: `${ctx.vaultForge}/${relativePath}`,
      content: frontmatter + body.trim() + "\n"
    };
  });
}
function inferTags(key, folder) {
  const base = ["tool/vault-forge"];
  const lower = key.toLowerCase();
  if (lower.includes("install") || lower.includes("start")) {
    base.push("topic/onboarding");
  } else if (lower.includes("schema") || lower.includes("lint") || lower.includes("structure")) {
    base.push("topic/schema");
  } else if (lower.includes("patch") || lower.includes("trouble") || lower.includes("repair")) {
    base.push("topic/procedure");
  } else {
    base.push("topic/reference");
  }
  return base;
}
function inferType(key) {
  const lower = key.toLowerCase();
  if (lower.includes("patch") || lower.includes("example"))
    return "procedure";
  return "reference";
}

// src/settings-tab.ts
var VaultForgeSettingsTab = class extends import_obsidian3.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }
  display() {
    const { containerEl } = this;
    containerEl.empty();
    new import_obsidian3.Setting(containerEl).setName("Install Documentation").setDesc(
      "Writes vault-native docs into your Vault Forge folder \u2014 command reference, schema guide, patch examples, and troubleshooting. Skips notes that already exist."
    ).addButton((btn) => {
      btn.setButtonText("Install Docs").setCta().onClick(async () => {
        await installVaultForgeDocumentation(this.plugin.app, this.plugin.settings);
      });
    });
    containerEl.createEl("h2", { text: "System Paths" });
    containerEl.createEl("p", {
      text: "All paths are relative to your vault root.",
      cls: "setting-item-description"
    });
    this.renderFolderPathSetting(
      containerEl,
      "System folder",
      "Root folder for all vault system files.",
      "systemFolder",
      "System"
    );
    this.renderFolderPathSetting(
      containerEl,
      "Vault Forge folder",
      "Folder for Vault Forge configuration and patch archives.",
      "vaultForgeFolder",
      "System/VaultForge"
    );
    this.renderSchemaNoteSetting(containerEl);
    this.renderFolderPathSetting(
      containerEl,
      "Exports folder",
      "Folder where inventory, lint reports, and indexes are written.",
      "exportsFolder",
      "System/Exports"
    );
    this.renderFolderPathSetting(
      containerEl,
      "Patches folder",
      "Folder where applied patch files are archived.",
      "patchesFolder",
      "System/VaultForge/Patches"
    );
    this.renderFolderPathSetting(
      containerEl,
      "Inbox folder",
      "Folder for draft notes awaiting import.",
      "inboxFolder",
      "System/Inbox"
    );
    this.renderFolderPathSetting(
      containerEl,
      "Patterns folder",
      "Folder containing pattern notes for lint validation.",
      "patternsFolder",
      "System/Patterns"
    );
    containerEl.createEl("h2", { text: "Patch" });
    this.renderPatchFileSetting(containerEl);
    new import_obsidian3.Setting(containerEl).setName("Backup before patch").setDesc(
      "Create a backup of each modified file before applying a patch. Backups are stored in System/VaultForge/Patches/Backups/."
    ).addToggle(
      (toggle) => toggle.setValue(this.plugin.settings.patchBackupEnabled).onChange(async (value) => {
        this.plugin.settings.patchBackupEnabled = value;
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian3.Setting(containerEl).setName("Generate restore manifest").setDesc(
      "Write a manifest file alongside each patch run so you can restore a full patch run in one step. Only active when backups are enabled."
    ).addToggle(
      (toggle) => toggle.setValue(this.plugin.settings.patchGenerateManifest).onChange(async (value) => {
        this.plugin.settings.patchGenerateManifest = value;
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian3.Setting(containerEl).setName("Run lint after patch").setDesc("Automatically run Vault Lint after a patch is applied.").addToggle(
      (toggle) => toggle.setValue(this.plugin.settings.patchAutoLintAfterApply).onChange(async (value) => {
        this.plugin.settings.patchAutoLintAfterApply = value;
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian3.Setting(containerEl).setName("Run maintenance after patch").setDesc("Automatically run Vault Maintenance after a patch is applied.").addToggle(
      (toggle) => toggle.setValue(this.plugin.settings.patchAutoMaintenanceAfterApply).onChange(async (value) => {
        this.plugin.settings.patchAutoMaintenanceAfterApply = value;
        await this.plugin.saveSettings();
      })
    );
    containerEl.createEl("h2", { text: "Lint" });
    new import_obsidian3.Setting(containerEl).setName("Strict mode").setDesc("Treat warnings as errors.").addToggle(
      (toggle) => toggle.setValue(this.plugin.settings.lintStrictMode).onChange(async (value) => {
        this.plugin.settings.lintStrictMode = value;
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian3.Setting(containerEl).setName("Lint run retention").setDesc("Number of lint run notes to keep.").addSlider(
      (slider) => slider.setLimits(5, 100, 5).setValue(this.plugin.settings.lintRunRetentionCount).setDynamicTooltip().onChange(async (value) => {
        this.plugin.settings.lintRunRetentionCount = value;
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian3.Setting(containerEl).setName("Lint file links").setDesc("Wrap file paths in [[wikilinks]] in lint run notes so you can navigate directly to affected files.").addToggle(
      (toggle) => toggle.setValue(this.plugin.settings.lintFileLinks).onChange(async (value) => {
        this.plugin.settings.lintFileLinks = value;
        await this.plugin.saveSettings();
      })
    );
    containerEl.createEl("h2", { text: "Maintenance" });
    new import_obsidian3.Setting(containerEl).setName("Backup retention (days)").setDesc("Delete patch backup files older than this many days.").addSlider(
      (slider) => slider.setLimits(1, 90, 1).setValue(this.plugin.settings.backupRetentionDays).setDynamicTooltip().onChange(async (value) => {
        this.plugin.settings.backupRetentionDays = value;
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian3.Setting(containerEl).setName("Inbox retention (days)").setDesc("Delete inbox files older than this many days.").addSlider(
      (slider) => slider.setLimits(1, 90, 1).setValue(this.plugin.settings.inboxRetentionDays).setDynamicTooltip().onChange(async (value) => {
        this.plugin.settings.inboxRetentionDays = value;
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian3.Setting(containerEl).setName("Lint history retention (days)").setDesc("Trim lint history entries older than this many days.").addSlider(
      (slider) => slider.setLimits(1, 365, 1).setValue(this.plugin.settings.lintHistoryRetentionDays).setDynamicTooltip().onChange(async (value) => {
        this.plugin.settings.lintHistoryRetentionDays = value;
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian3.Setting(containerEl).setName("Lint history max entries").setDesc("Hard cap on the number of lint history entries to retain.").addSlider(
      (slider) => slider.setLimits(10, 500, 10).setValue(this.plugin.settings.lintHistoryMaxEntries).setDynamicTooltip().onChange(async (value) => {
        this.plugin.settings.lintHistoryMaxEntries = value;
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian3.Setting(containerEl).setName("Patch report retention").setDesc("Number of patch report notes to keep.").addSlider(
      (slider) => slider.setLimits(5, 100, 5).setValue(this.plugin.settings.patchReportRetentionCount).setDynamicTooltip().onChange(async (value) => {
        this.plugin.settings.patchReportRetentionCount = value;
        await this.plugin.saveSettings();
      })
    );
  }
  // ── Helpers ───────────────────────────────────────────────────────
  renderFolderPathSetting(containerEl, name, desc, settingKey, fallback) {
    var _a;
    const currentValue = String((_a = this.plugin.settings[settingKey]) != null ? _a : fallback);
    new import_obsidian3.Setting(containerEl).setName(name).setDesc(`${desc} Current: ${currentValue}`).addButton(
      (btn) => btn.setButtonText("Choose").onClick(() => {
        new FolderSuggestModal(this.app, async (folder) => {
          const selectedPath = folder.path || fallback;
          this.plugin.settings[settingKey] = selectedPath;
          await this.plugin.saveSettings();
          this.display();
        }).open();
      })
    );
  }
  renderSchemaNoteSetting(containerEl) {
    const currentPath = `${this.plugin.settings.schemaNoteFolder}/${this.plugin.settings.schemaNoteFile}`;
    new import_obsidian3.Setting(containerEl).setName("Schema note").setDesc(`Path to schema.md relative to vault root. Current: ${currentPath}`).addButton(
      (btn) => btn.setButtonText("Choose").onClick(() => {
        new MarkdownFileSuggestModal(this.app, async (file) => {
          const lastSlash = file.path.lastIndexOf("/");
          this.plugin.settings.schemaNoteFolder = lastSlash >= 0 ? file.path.substring(0, lastSlash) : "";
          this.plugin.settings.schemaNoteFile = lastSlash >= 0 ? file.path.substring(lastSlash + 1) : file.path;
          await this.plugin.saveSettings();
          this.display();
        }).open();
      })
    );
  }
  renderPatchFileSetting(containerEl) {
    const fallback = "System/VaultForge/Patches/vault-patch.md";
    const currentPath = this.plugin.settings.patchDefaultFile || fallback;
    new import_obsidian3.Setting(containerEl).setName("Default patch file").setDesc(`Path to the patch note loaded by Apply Vault Patch. Current: ${currentPath}`).addButton(
      (btn) => btn.setButtonText("Choose").onClick(() => {
        new PatchFileSuggestModal(this.app, async (file) => {
          this.plugin.settings.patchDefaultFile = file.path;
          await this.plugin.saveSettings();
          this.display();
        }).open();
      })
    );
  }
};
var FolderSuggestModal = class extends import_obsidian3.FuzzySuggestModal {
  constructor(app, onChooseFolder) {
    super(app);
    this.onChooseFolder = onChooseFolder;
    this.setPlaceholder("Choose a folder...");
  }
  getItems() {
    const folders = [];
    const walk = (file) => {
      if (file instanceof import_obsidian3.TFolder) {
        folders.push(file);
        for (const child of file.children) {
          walk(child);
        }
      }
    };
    walk(this.app.vault.getRoot());
    return folders;
  }
  getItemText(folder) {
    return folder.path || "/";
  }
  onChooseItem(folder) {
    this.onChooseFolder(folder);
  }
};
var MarkdownFileSuggestModal = class extends import_obsidian3.FuzzySuggestModal {
  constructor(app, onChooseFile) {
    super(app);
    this.onChooseFile = onChooseFile;
    this.setPlaceholder("Choose a markdown note...");
  }
  getItems() {
    return this.app.vault.getMarkdownFiles();
  }
  getItemText(file) {
    return file.path;
  }
  onChooseItem(file) {
    this.onChooseFile(file);
  }
};
var PatchFileSuggestModal = class extends import_obsidian3.FuzzySuggestModal {
  constructor(app, onChooseFile) {
    super(app);
    this.onChooseFile = onChooseFile;
    this.setPlaceholder("Choose a patch note or YAML file...");
  }
  getItems() {
    return this.app.vault.getFiles().filter((file) => {
      const path = file.path.toLowerCase();
      return path.endsWith(".md") || path.endsWith(".yaml") || path.endsWith(".yml");
    });
  }
  getItemText(file) {
    return file.path;
  }
  onChooseItem(file) {
    this.onChooseFile(file);
  }
};

// src/utils/schema.ts
var import_obsidian4 = require("obsidian");
async function loadSchema(app, settings) {
  const paths = getVaultPaths(settings);
  const file = app.vault.getAbstractFileByPath(paths.schemaMd);
  if (!(file instanceof import_obsidian4.TFile)) {
    console.warn(`[VaultForge] schema.md not found at: ${paths.schemaMd}`);
    return null;
  }
  let raw;
  try {
    raw = await app.vault.read(file);
  } catch (e) {
    console.warn(`[VaultForge] Could not read schema.md:`, e);
    return null;
  }
  return parseSchemaNote(raw);
}
function parseSchemaNote(raw) {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i;
  const fmMatch = raw.match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n?([\s\S]*)$/);
  if (!fmMatch) {
    console.warn("[VaultForge] schema.md is missing valid YAML frontmatter");
    return null;
  }
  const fmText = fmMatch[1];
  const bodyText = (_a = fmMatch[2]) != null ? _a : "";
  let fmUpdated = "";
  try {
    const fm = (0, import_obsidian4.parseYaml)(fmText);
    fmUpdated = (fm == null ? void 0 : fm.updated) ? String(fm.updated) : "";
  } catch (e) {
  }
  const versionMatch = bodyText.match(/^version::\s*"?([^"\s]+)"?\s*$/m);
  const version = (_b = versionMatch == null ? void 0 : versionMatch[1]) != null ? _b : "";
  const contractYaml = extractContractBlock(bodyText);
  if (!contractYaml) {
    console.warn("[VaultForge] Could not find schema contract YAML block in schema.md");
    return null;
  }
  let contract;
  try {
    contract = (0, import_obsidian4.parseYaml)(contractYaml);
  } catch (e) {
    console.warn("[VaultForge] Could not parse schema contract YAML:", e);
    return null;
  }
  if (!contract) {
    console.warn("[VaultForge] Schema contract block is empty");
    return null;
  }
  const contractMeta = (_c = contract.meta) != null ? _c : {};
  const meta = {
    version,
    updated: fmUpdated,
    author: contractMeta.author ? String(contractMeta.author) : void 0,
    schemaRef: contractMeta.schemaRef ? String(contractMeta.schemaRef) : void 0
  };
  const requiredFields = coerceFieldArray(contract.required_fields);
  const optionalFields = coerceFieldArray(contract.optional_fields);
  const rawInline = contract.inline_fields;
  const inlineFields = Array.isArray(rawInline) ? rawInline.map(String) : [];
  const rawTagRules = (_d = contract.tag_rules) != null ? _d : {};
  const tagRules = {
    require_namespace: Boolean((_e = rawTagRules.require_namespace) != null ? _e : true),
    unknown_tags: (_f = rawTagRules.unknown_tags) != null ? _f : "warning",
    severity: (_g = rawTagRules.severity) != null ? _g : "warning",
    allowed_namespaces: Array.isArray(rawTagRules.allowed_namespaces) ? rawTagRules.allowed_namespaces.map(String) : []
  };
  const rawExempt = contract.exempt_paths;
  const exemptPaths = Array.isArray(rawExempt) ? rawExempt.map(String) : [];
  return {
    meta,
    required_fields: requiredFields,
    optional_fields: optionalFields,
    inline_fields: inlineFields,
    tag_rules: tagRules,
    exempt_paths: exemptPaths,
    lint_output: (_h = contract.lint_output) != null ? _h : {},
    patch_engine: (_i = contract.patch_engine) != null ? _i : {}
  };
}
function validateSchemaNote(raw) {
  var _a;
  const issues = [];
  const fmMatch = raw.match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n?([\s\S]*)$/);
  if (!fmMatch) {
    issues.push({ severity: "error", message: "schema.md is missing YAML frontmatter block" });
    return issues;
  }
  const bodyText = (_a = fmMatch[2]) != null ? _a : "";
  if (!/^version::\s*"?[^"\s]+"?\s*$/m.test(bodyText)) {
    issues.push({
      severity: "error",
      message: "schema.md body is missing 'version:: ...' inline metadata"
    });
  }
  const contractYaml = extractContractBlock(bodyText);
  if (!contractYaml) {
    issues.push({
      severity: "error",
      message: "Could not find a fenced YAML block under # Contract in schema.md"
    });
    return issues;
  }
  try {
    const contract = (0, import_obsidian4.parseYaml)(contractYaml);
    if (!contract) {
      issues.push({ severity: "error", message: "Schema contract block is empty" });
      return issues;
    }
    if (!contract.required_fields) {
      issues.push({ severity: "error", message: "Schema contract is missing required_fields" });
    }
    if (!contract.tag_rules) {
      issues.push({ severity: "warning", message: "Schema contract is missing tag_rules" });
    }
    const contractMeta = contract.meta;
    if (contractMeta == null ? void 0 : contractMeta.version) {
      issues.push({
        severity: "error",
        message: "Do not define meta.version in the schema YAML block \u2014 use 'version:: ...' in the body instead"
      });
    }
  } catch (e) {
    issues.push({
      severity: "error",
      message: `Schema contract YAML is not parseable: ${e}`
    });
  }
  return issues;
}
function extractContractBlock(bodyText) {
  const underContract = bodyText.match(
    /^#\s+Contract\s*$[\s\S]*?^```+\s*yaml\s*\r?\n([\s\S]*?)^```+\s*$/m
  );
  if (underContract)
    return underContract[1].trim();
  const anywhere = bodyText.match(/^```+\s*yaml\s*\r?\n([\s\S]*?)^```+\s*$/m);
  if (anywhere)
    return anywhere[1].trim();
  return null;
}
function coerceFieldArray(raw) {
  if (!Array.isArray(raw))
    return [];
  return raw.filter((item) => item !== null && typeof item === "object").map((item) => {
    var _a, _b, _c;
    return {
      name: String((_a = item.name) != null ? _a : ""),
      type: (_b = item.type) != null ? _b : "string",
      values: Array.isArray(item.values) ? item.values.map(String) : void 0,
      severity: (_c = item.severity) != null ? _c : "warning",
      min_items: item.min_items !== void 0 ? Number(item.min_items) : void 0,
      strict_parse: item.strict_parse !== void 0 ? Boolean(item.strict_parse) : void 0,
      stale_after_days: item.stale_after_days !== void 0 ? Number(item.stale_after_days) : void 0,
      description: item.description ? String(item.description) : void 0,
      lint_rules: Array.isArray(item.lint_rules) ? item.lint_rules : void 0
    };
  }).filter((f) => f.name.length > 0);
}

// src/schema-cache.ts
var SchemaCache = class {
  constructor(app, settings) {
    this.cache = null;
    this.app = app;
    this.settings = settings;
  }
  /**
   * Returns the cached schema, loading it first if not yet loaded.
   */
  async get() {
    if (!this.cache) {
      await this.refresh();
    }
    return this.cache;
  }
  /**
   * Forces a fresh load from schema.md.
   * Called after Validate Schema or settings changes.
   */
  async refresh() {
    this.cache = await loadSchema(this.app, this.settings);
    return this.cache;
  }
  /**
   * Returns the cached schema without loading — may be null.
   */
  peek() {
    return this.cache;
  }
  /**
   * Clears the cache — next get() will reload.
   */
  invalidate() {
    this.cache = null;
  }
  /**
   * Updates settings reference (called when settings change).
   * Only invalidates the cache if the schema path changed — non-path settings
   * (lint toggles, retention counts, etc.) don't affect the cached schema, so
   * there is no reason to clear a valid cache when they change.
   */
  updateSettings(settings) {
    const oldPath = `${this.settings.schemaNoteFolder}/${this.settings.schemaNoteFile}`;
    const newPath = `${settings.schemaNoteFolder}/${settings.schemaNoteFile}`;
    this.settings = settings;
    if (oldPath !== newPath) {
      this.invalidate();
    }
  }
  // ── Schema field helpers ────────────────────────────────────────────────────
  /**
   * Returns all field names from required + optional fields.
   */
  getFieldNames() {
    if (!this.cache)
      return [];
    return [
      ...this.cache.required_fields.map((f) => f.name),
      ...this.cache.optional_fields.map((f) => f.name)
    ];
  }
  /**
   * Returns all enum-type field names — these should have lowercased values.
   * Used by Normalize Frontmatter to replace the hardcoded field list.
   */
  getEnumFieldNames() {
    if (!this.cache)
      return [];
    return [
      ...this.cache.required_fields.filter((f) => f.type === "enum").map((f) => f.name),
      ...this.cache.optional_fields.filter((f) => f.type === "enum").map((f) => f.name)
    ];
  }
  /**
   * Returns allowed values for a specific field, or null if not an enum.
   */
  getEnumValues(fieldName) {
    if (!this.cache)
      return null;
    const all = [...this.cache.required_fields, ...this.cache.optional_fields];
    const field = all.find((f) => f.name === fieldName);
    if (!field || field.type !== "enum" || !field.values)
      return null;
    return field.values;
  }
  /**
   * Returns the field type for a given field name, or null if not found.
   */
  getFieldType(fieldName) {
    var _a;
    if (!this.cache)
      return null;
    const all = [...this.cache.required_fields, ...this.cache.optional_fields];
    const field = all.find((f) => f.name === fieldName);
    return (_a = field == null ? void 0 : field.type) != null ? _a : null;
  }
  /**
   * Returns a reasonable default value for a field based on its type and name.
   * Used by Vault Repair to pre-populate fields.
   */
  getDefaultValue(fieldName) {
    var _a, _b;
    const type = this.getFieldType(fieldName);
    const values = this.getEnumValues(fieldName);
    switch (fieldName) {
      case "created":
      case "updated":
      case "review_by":
        return (/* @__PURE__ */ new Date()).toISOString().substring(0, 10);
      case "ai_private":
        return false;
      case "review_cycle":
        return "never";
      case "status":
        return (values == null ? void 0 : values.includes("active")) ? "active" : (_a = values == null ? void 0 : values[0]) != null ? _a : "";
    }
    switch (type) {
      case "boolean":
        return false;
      case "enum":
        return (_b = values == null ? void 0 : values[0]) != null ? _b : "";
      case "date":
        return (/* @__PURE__ */ new Date()).toISOString().substring(0, 10);
      case "list":
        return [];
      default:
        return "";
    }
  }
};

// src/commands/apply-patch.ts
var import_obsidian11 = require("obsidian");

// src/patch-engine.ts
var import_obsidian6 = require("obsidian");
init_frontmatter();

// src/utils/tags.ts
function getTags(frontmatter) {
  const raw = frontmatter["tags"];
  if (raw === null || raw === void 0)
    return [];
  const list = Array.isArray(raw) ? raw : [raw];
  return list.filter((v) => v !== null && v !== void 0).map((v) => String(v).trim()).filter((v) => v.length > 0);
}
function setTags(frontmatter, tags) {
  frontmatter["tags"] = normalizeTags(tags);
}
function normalizeTags(tags) {
  const seen = /* @__PURE__ */ new Set();
  const result = [];
  for (const tag of tags) {
    const trimmed = tag.trim();
    if (!trimmed)
      continue;
    const lower = trimmed.toLowerCase();
    if (!seen.has(lower)) {
      seen.add(lower);
      result.push(trimmed);
    }
  }
  return result.sort(
    (a, b) => a.toLowerCase().localeCompare(b.toLowerCase())
  );
}
function addTag(tags, tag) {
  const trimmed = tag.trim();
  const lower = trimmed.toLowerCase();
  if (tags.some((t) => t.toLowerCase() === lower)) {
    return tags;
  }
  return [...tags, trimmed];
}
function removeTag(tags, tag) {
  const lower = tag.trim().toLowerCase();
  const filtered = tags.filter((t) => t.toLowerCase() !== lower);
  return filtered.length === tags.length ? tags : filtered;
}
function convertTagSeparator(tag) {
  const trimmed = tag.trim();
  if (/^[A-Za-z0-9_.-]+:[A-Za-z0-9_.-]+$/.test(trimmed)) {
    return trimmed.replace(":", "/");
  }
  return trimmed;
}
function isInvalidTag(tag) {
  const lower = tag.trim().toLowerCase();
  return /^(domain|status|type)(\/.*)?$/.test(lower);
}

// src/patch-engine.ts
init_files();
async function loadPatchFile(app, patchFilePath) {
  var _a;
  const file = app.vault.getAbstractFileByPath((0, import_obsidian6.normalizePath)(patchFilePath));
  if (!(file instanceof import_obsidian6.TFile)) {
    return null;
  }
  let raw;
  try {
    raw = await app.vault.read(file);
  } catch (e) {
    console.warn(`[VaultForge] Could not read patch file: ${patchFilePath}`, e);
    return null;
  }
  try {
    const yamlText = extractPatchYaml(raw, patchFilePath);
    if (!yamlText.trim()) {
      console.warn(`[VaultForge] Patch file contains no YAML payload: ${patchFilePath}`);
      return null;
    }
    const parsed = (0, import_obsidian6.parseYaml)(yamlText);
    const meta = (_a = parsed == null ? void 0 : parsed.meta) != null ? _a : {};
    const operations = Array.isArray(parsed == null ? void 0 : parsed.operations) ? parsed.operations : [];
    return { meta, operations };
  } catch (e) {
    console.warn(`[VaultForge] Could not parse patch YAML:`, e);
    return null;
  }
}
async function applyPatch(app, settings, patchFile, patchFilePath, dryRun) {
  var _a, _b, _c, _d, _e;
  const paths = getVaultPaths(settings);
  const runId = safeTimestamp();
  const appliedAt = (/* @__PURE__ */ new Date()).toISOString();
  const results = [];
  const manifest = [];
  const backedUp = /* @__PURE__ */ new Set();
  async function maybeBackup(file) {
    var _a2;
    if (!settings.patchBackupEnabled || dryRun)
      return null;
    if (backedUp.has(file.path)) {
      const existing = manifest.find((e) => e.file === file.path);
      return (_a2 = existing == null ? void 0 : existing.backup) != null ? _a2 : null;
    }
    const backupPath = await backupNote(app, file, paths.patchBackups);
    if (backupPath) {
      backedUp.add(file.path);
      manifest.push({ file: file.path, backup: backupPath });
    }
    return backupPath;
  }
  for (const op of patchFile.operations) {
    const opName = (_a = op.op) != null ? _a : "<unknown>";
    const targets = resolveTargets(app, op.target, op.target_pattern);
    if (targets.length === 0) {
      results.push({
        op: opName,
        file: (_c = (_b = op.target) != null ? _b : op.target_pattern) != null ? _c : "<no target>",
        status: "error",
        detail: "No matching files found"
      });
      continue;
    }
    for (const file of targets) {
      let result;
      switch (opName) {
        case "set_field":
          result = await applySetField(app, op, file, dryRun);
          break;
        case "remove_field":
          result = await applyRemoveField(app, op, file, dryRun);
          break;
        case "add_tag":
          result = await applyAddTag(app, op, file, dryRun);
          break;
        case "remove_tag":
          result = await applyRemoveTag(app, op, file, dryRun);
          break;
        case "replace_tag":
          result = await applyReplaceTagOp(app, op, file, dryRun);
          break;
        case "normalize_tags":
          result = await applyNormalizeTags(app, op, file, dryRun);
          break;
        case "compute_field":
          result = await applyComputeField(app, op, file, dryRun);
          break;
        case "sort_frontmatter":
          result = await applySortFrontmatter(app, op, file, dryRun);
          break;
        case "move_note":
          result = await applyMoveNote(app, op, file, settings, dryRun);
          break;
        default:
          result = {
            op: opName,
            file: file.path,
            status: "error",
            detail: `Unknown operation: '${opName}'`
          };
      }
      if (result.status === "changed") {
        await maybeBackup(file);
      }
      results.push(result);
    }
  }
  return {
    runId,
    patchFile: patchFilePath,
    description: (_d = patchFile.meta.description) != null ? _d : "",
    appliedAt,
    schemaVersion: (_e = patchFile.meta.schema_version) != null ? _e : "",
    dryRun,
    results,
    manifest
  };
}
async function applySetField(app, op, file, dryRun) {
  var _a;
  const fieldName = op.field;
  if (!fieldName) {
    return opError("set_field", file, "Missing field name");
  }
  const note = await readNote(app, file);
  if (!note)
    return opError("set_field", file, "Could not read file");
  const fm = note.frontmatter;
  const currentValue = fm[fieldName];
  const onlyIfMissing = (_a = op.only_if_missing) != null ? _a : false;
  if (onlyIfMissing && isFieldPresent(fm, fieldName)) {
    return opSkipped("set_field", file, `Field '${fieldName}' already has a value`);
  }
  let newValue;
  try {
    newValue = resolveFieldValue(op, file);
  } catch (e) {
    return opError("set_field", file, String(e));
  }
  const currentStr = currentValue === void 0 ? "<missing>" : JSON.stringify(currentValue);
  const newStr = JSON.stringify(newValue);
  if (currentStr === newStr) {
    return opSkipped("set_field", file, `Field '${fieldName}' already = ${newStr}`);
  }
  if (!dryRun) {
    fm[fieldName] = newValue;
    await writeNote(app, note);
  }
  return opChanged("set_field", file, `Set '${fieldName}': ${currentStr} \u2192 ${newStr}`);
}
async function applyRemoveField(app, op, file, dryRun) {
  const fieldName = op.field;
  if (!fieldName)
    return opError("remove_field", file, "Missing field name");
  const note = await readNote(app, file);
  if (!note)
    return opError("remove_field", file, "Could not read file");
  if (!isFieldPresent(note.frontmatter, fieldName)) {
    return opSkipped("remove_field", file, `Field '${fieldName}' not present`);
  }
  if (!dryRun) {
    delete note.frontmatter[fieldName];
    await writeNote(app, note);
  }
  return opChanged("remove_field", file, `Removed field '${fieldName}'`);
}
async function applyAddTag(app, op, file, dryRun) {
  const tag = op.tag;
  if (!tag)
    return opError("add_tag", file, "Missing tag");
  const note = await readNote(app, file);
  if (!note)
    return opError("add_tag", file, "Could not read file");
  const current = getTags(note.frontmatter);
  const updated = addTag(current, tag);
  if (updated === current) {
    return opSkipped("add_tag", file, `Tag '${tag}' already present`);
  }
  if (!dryRun) {
    setTags(note.frontmatter, updated);
    await writeNote(app, note);
  }
  return opChanged("add_tag", file, `Added tag '${tag}'`);
}
async function applyRemoveTag(app, op, file, dryRun) {
  const tag = op.tag;
  if (!tag)
    return opError("remove_tag", file, "Missing tag");
  const note = await readNote(app, file);
  if (!note)
    return opError("remove_tag", file, "Could not read file");
  const current = getTags(note.frontmatter);
  const updated = removeTag(current, tag);
  if (updated === current) {
    return opSkipped("remove_tag", file, `Tag '${tag}' not present`);
  }
  if (!dryRun) {
    setTags(note.frontmatter, updated);
    await writeNote(app, note);
  }
  return opChanged("remove_tag", file, `Removed tag '${tag}'`);
}
async function applyReplaceTagOp(app, op, file, dryRun) {
  const oldTag = op.old_tag;
  const newTagVal = op.new_tag;
  if (!oldTag || !newTagVal) {
    return opError("replace_tag", file, "Missing old_tag or new_tag");
  }
  const note = await readNote(app, file);
  if (!note)
    return opError("replace_tag", file, "Could not read file");
  const current = getTags(note.frontmatter);
  const hasOld = current.some((t) => t.toLowerCase() === oldTag.toLowerCase());
  if (!hasOld) {
    return opSkipped("replace_tag", file, `Tag '${oldTag}' not present`);
  }
  const hasNew = current.some((t) => t.toLowerCase() === newTagVal.toLowerCase());
  if (hasNew) {
    return opSkipped("replace_tag", file, `Tag '${newTagVal}' already present`);
  }
  const updated = current.map(
    (t) => t.toLowerCase() === oldTag.toLowerCase() ? newTagVal : t
  );
  if (!dryRun) {
    setTags(note.frontmatter, updated);
    await writeNote(app, note);
  }
  return opChanged("replace_tag", file, `Replaced tag '${oldTag}' \u2192 '${newTagVal}'`);
}
async function applyNormalizeTags(app, op, file, dryRun) {
  const note = await readNote(app, file);
  if (!note)
    return opError("normalize_tags", file, "Could not read file");
  const current = getTags(note.frontmatter);
  const normalized = normalizeTags(current);
  const currentStr = current.join("|");
  const normalizedStr = normalized.join("|");
  if (currentStr === normalizedStr) {
    return opSkipped("normalize_tags", file, "Tags already normalized");
  }
  if (!dryRun) {
    setTags(note.frontmatter, normalized);
    await writeNote(app, note);
  }
  return opChanged("normalize_tags", file, "Normalized tags");
}
async function applyComputeField(app, op, file, dryRun) {
  var _a, _b, _c, _d;
  const fieldName = op.field;
  const strategy = op.strategy;
  if (!fieldName)
    return opError("compute_field", file, "Missing field name");
  if (!strategy)
    return opError("compute_field", file, "Missing strategy");
  const note = await readNote(app, file);
  if (!note)
    return opError("compute_field", file, "Could not read file");
  const fm = note.frontmatter;
  const whenMissing = (_a = op.when_missing) != null ? _a : false;
  if (whenMissing && isFieldPresent(fm, fieldName)) {
    return opSkipped("compute_field", file, `Field '${fieldName}' already has a value`);
  }
  const format = (_b = op.format) != null ? _b : "yyyy-MM-dd";
  let newValue;
  try {
    switch (strategy) {
      case "file_created_time": {
        newValue = formatDate(new Date(file.stat.ctime), format);
        break;
      }
      case "file_modified_time": {
        newValue = formatDate(new Date(file.stat.mtime), format);
        break;
      }
      case "recent_activity": {
        const days = (_c = op.days) != null ? _c : 30;
        const valueIfTrue = op.value_if_true;
        if (!valueIfTrue) {
          return opError("compute_field", file, "recent_activity requires value_if_true");
        }
        const skipIf = (_d = op.skip_if) != null ? _d : [];
        const currentVal2 = fm[fieldName] ? String(fm[fieldName]).trim() : "";
        if (skipIf.includes(currentVal2)) {
          return opSkipped("compute_field", file, `Field '${fieldName}' is '${currentVal2}' \u2014 excluded by skip_if`);
        }
        const cutoff = Date.now() - days * 24 * 60 * 60 * 1e3;
        if (file.stat.mtime >= cutoff) {
          newValue = valueIfTrue;
        } else {
          return opSkipped("compute_field", file, `File not modified in last ${days} days`);
        }
        break;
      }
      default:
        return opError("compute_field", file, `Unsupported strategy '${strategy}'`);
    }
  } catch (e) {
    return opError("compute_field", file, String(e));
  }
  const currentVal = fm[fieldName] !== void 0 ? String(fm[fieldName]) : "<missing>";
  if (currentVal === newValue) {
    return opSkipped("compute_field", file, `Field '${fieldName}' already = '${newValue}'`);
  }
  if (!dryRun) {
    fm[fieldName] = newValue;
    await writeNote(app, note);
  }
  return opChanged("compute_field", file, `Computed '${fieldName}': '${currentVal}' \u2192 '${newValue}'`);
}
async function applySortFrontmatter(app, op, file, dryRun) {
  const note = await readNote(app, file);
  if (!note)
    return opError("sort_frontmatter", file, "Could not read file");
  if (!note.hasFrontmatter) {
    return opSkipped("sort_frontmatter", file, "No frontmatter found");
  }
  const sorted = sortFrontmatterFields(note.frontmatter);
  const originalKeys = Object.keys(note.frontmatter).join(",");
  const sortedKeys = Object.keys(sorted).join(",");
  if (originalKeys === sortedKeys) {
    return opSkipped("sort_frontmatter", file, "Frontmatter already in correct order");
  }
  if (!dryRun) {
    note.frontmatter = sorted;
    await writeNote(app, note);
  }
  return opChanged("sort_frontmatter", file, "Sorted frontmatter fields");
}
async function applyMoveNote(app, op, file, settings, dryRun) {
  const destinationFolder = op.destination_folder;
  const sourceRoot = op.source_root;
  if (!destinationFolder)
    return opError("move_note", file, "Missing destination_folder");
  if (!sourceRoot)
    return opError("move_note", file, "Missing source_root");
  if (op.strip_frontmatter && op.frontmatter) {
    return opError("move_note", file, "Cannot use both strip_frontmatter and frontmatter");
  }
  const normalizedSourceRoot = (0, import_obsidian6.normalizePath)(sourceRoot).toLowerCase();
  const filePath = (0, import_obsidian6.normalizePath)(file.path);
  if (!filePath.toLowerCase().startsWith(normalizedSourceRoot + "/")) {
    return opError("move_note", file, `File is not under source_root '${sourceRoot}'`);
  }
  const relativeUnderSource = file.path.substring(sourceRoot.length).replace(/^\//, "");
  const destPath = (0, import_obsidian6.normalizePath)(`${destinationFolder}/${relativeUnderSource}`);
  if (filePath === destPath.toLowerCase()) {
    return opSkipped("move_note", file, "Already in correct location");
  }
  const existing = app.vault.getAbstractFileByPath(destPath);
  if (existing) {
    return opError("move_note", file, `Destination already exists: ${destPath}`);
  }
  if (!dryRun) {
    await ensureFolder(app, (0, import_obsidian6.normalizePath)(destPath.substring(0, destPath.lastIndexOf("/"))));
    if (op.strip_frontmatter || op.frontmatter) {
      const note = await readNote(app, file);
      let content = await app.vault.read(file);
      if (op.strip_frontmatter) {
        const bodyMatch = content.match(/^---\r?\n[\s\S]*?\r?\n---\r?\n?([\s\S]*)$/);
        content = bodyMatch ? bodyMatch[1] : content;
      } else if (op.frontmatter && note) {
        const merged = { ...note.frontmatter, ...op.frontmatter };
        const sorted = sortFrontmatterFields(merged);
        const yamlStr = (0, import_obsidian6.stringifyYaml)(sorted).trimEnd();
        const bodyMatch = content.match(/^---\r?\n[\s\S]*?\r?\n---\r?\n?([\s\S]*)$/);
        const body = bodyMatch ? bodyMatch[1] : content;
        content = `---
${yamlStr}
---
${body}`;
      }
      await app.vault.create(destPath, content);
      await app.vault.delete(file);
    } else {
      await app.vault.rename(file, destPath);
    }
  }
  return opChanged("move_note", file, `Moved \u2192 ${destPath}`);
}
function extractPatchYaml(raw, patchFilePath) {
  var _a, _b;
  const lowerPath = patchFilePath.toLowerCase();
  if (!lowerPath.endsWith(".md")) {
    return raw;
  }
  const match = raw.match(/```ya?ml\s*\r?\n([\s\S]*?)```/i);
  return (_b = (_a = match == null ? void 0 : match[1]) == null ? void 0 : _a.trim()) != null ? _b : "";
}
function resolveFieldValue(op, file) {
  const hasLiteralValue = "value" in op && op.value !== void 0;
  const valueFrom = op.value_from;
  if (hasLiteralValue && valueFrom) {
    throw new Error("Cannot specify both 'value' and 'value_from'");
  }
  if (!hasLiteralValue && !valueFrom) {
    throw new Error("set_field requires either 'value' or 'value_from'");
  }
  if (hasLiteralValue)
    return op.value;
  const parts = (0, import_obsidian6.normalizePath)(file.path).split("/");
  const fileName = parts[parts.length - 1];
  const baseName = fileName.replace(/\.md$/, "");
  const folderName = parts.length >= 2 ? parts[parts.length - 2] : "";
  const parentFolder = parts.length >= 3 ? parts[parts.length - 3] : "";
  let value;
  switch (valueFrom) {
    case "filename":
      value = fileName;
      break;
    case "basename":
      value = baseName;
      break;
    case "folder":
      value = folderName;
      break;
    case "parent_folder":
      value = parentFolder;
      break;
    case "path": {
      const idx = op.path_segment_index;
      if (idx === void 0)
        throw new Error("value_from: path requires path_segment_index");
      if (idx < 0 || idx >= parts.length)
        throw new Error(`path_segment_index ${idx} out of range`);
      value = parts[idx];
      break;
    }
    default:
      throw new Error(`Unsupported value_from '${valueFrom}'`);
  }
  const trimPrefix = op.trim_prefix;
  if (trimPrefix && value.startsWith(trimPrefix)) {
    value = value.substring(trimPrefix.length);
  }
  const trimSuffix = op.trim_suffix;
  if (trimSuffix && value.endsWith(trimSuffix)) {
    value = value.substring(0, value.length - trimSuffix.length);
  }
  if (op.lowercase && op.uppercase)
    throw new Error("Cannot specify both lowercase and uppercase");
  if (op.lowercase)
    value = value.toLowerCase();
  if (op.uppercase)
    value = value.toUpperCase();
  return value;
}
function formatDate(date, format) {
  if (format === "yyyy-MM-dd") {
    return date.toISOString().substring(0, 10);
  }
  return date.toISOString().substring(0, 10);
}
function opChanged(op, file, detail) {
  return { op, file: file.path, status: "changed", detail };
}
function opSkipped(op, file, detail) {
  return { op, file: file.path, status: "skipped", detail };
}
function opError(op, file, detail) {
  const filePath = typeof file === "string" ? file : file.path;
  return { op, file: filePath, status: "error", detail };
}

// src/patch-manifest.ts
var import_obsidian7 = require("obsidian");
init_files();
async function writeRestoreManifest(app, settings, result) {
  if (!settings.patchBackupEnabled || !settings.patchGenerateManifest)
    return;
  if (result.manifest.length === 0)
    return;
  if (result.dryRun)
    return;
  const paths = getVaultPaths(settings);
  await ensureFolder(app, paths.patchReports);
  const manifest = {
    run_id: result.runId,
    patch_file: result.patchFile,
    description: result.description,
    applied_at: result.appliedAt,
    schema_version: result.schemaVersion,
    changes: result.manifest
  };
  const manifestPath = (0, import_obsidian7.normalizePath)(
    `${paths.patchReports}/${result.runId}-patch-manifest.json`
  );
  await app.vault.create(manifestPath, JSON.stringify(manifest, null, 2));
}
async function archivePatchFile(app, settings, result) {
  if (result.dryRun)
    return;
  const paths = getVaultPaths(settings);
  await ensureFolder(app, paths.patchApplied);
  const sourceFile = app.vault.getAbstractFileByPath(
    (0, import_obsidian7.normalizePath)(result.patchFile)
  );
  if (!(sourceFile instanceof import_obsidian7.TFile))
    return;
  const sourceExt = sourceFile.extension || "md";
  const archivePath = (0, import_obsidian7.normalizePath)(
    `${paths.patchApplied}/${result.runId}-vault-patch.${sourceExt}`
  );
  if (app.vault.getAbstractFileByPath(archivePath))
    return;
  await app.vault.rename(sourceFile, archivePath);
}
async function writePatchReport(app, settings, result) {
  const paths = getVaultPaths(settings);
  const folder = result.dryRun ? paths.exports : paths.patchReports;
  await ensureFolder(app, folder);
  const mode = result.dryRun ? "dry-run" : "apply";
  const reportPath = (0, import_obsidian7.normalizePath)(
    `${folder}/${result.runId}-patch-report-${mode}.md`
  );
  const changed = result.results.filter((r) => r.status === "changed");
  const skipped = result.results.filter((r) => r.status === "skipped");
  const errors = result.results.filter((r) => r.status === "error");
  const today = todayString();
  const content = buildReportNote(result, changed, skipped, errors, today, mode);
  const existing = app.vault.getAbstractFileByPath(reportPath);
  if (existing instanceof import_obsidian7.TFile) {
    await app.vault.modify(existing, content);
  } else {
    await app.vault.create(reportPath, content);
  }
  return reportPath;
}
function buildReportNote(result, changed, skipped, errors, today, mode) {
  const lines = [
    "---",
    "type: reference",
    "status: active",
    "tags:",
    "  - meta/patch-report",
    `created: ${today}`,
    `updated: ${today}`,
    "ai_private: false",
    "review_cycle: never",
    "---",
    "",
    `source:: ${result.patchFile}`,
    `patch_mode:: ${mode}`,
    `changed_count:: ${changed.length}`,
    `skipped_count:: ${skipped.length}`,
    `error_count:: ${errors.length}`,
    "",
    "# Patch Report",
    "",
    "## Summary",
    "",
    `- Mode: ${mode}`,
    `- Run ID: ${result.runId}`,
    `- Patch file: ${result.patchFile}`,
    `- Description: ${result.description}`,
    `- Applied at: ${result.appliedAt}`,
    `- Changed: ${changed.length}`,
    `- Skipped: ${skipped.length}`,
    `- Errors: ${errors.length}`,
    ""
  ];
  if (errors.length > 0) {
    lines.push("## Errors", "");
    for (const r of errors) {
      lines.push(`- \`[${r.op}]\` \`${r.file}\` \u2014 ${r.detail}`);
    }
    lines.push("");
  }
  if (changed.length > 0) {
    lines.push("## Changed", "");
    const byOp = groupBy(changed, (r) => r.op);
    for (const [op, items] of Object.entries(byOp)) {
      lines.push(`### ${op}`, "");
      for (const r of items) {
        lines.push(`- \`${r.file}\` \u2014 ${r.detail}`);
      }
      lines.push("");
    }
  }
  if (skipped.length > 0) {
    lines.push("## Skipped", "");
    for (const r of skipped) {
      lines.push(`- \`[${r.op}]\` \`${r.file}\` \u2014 ${r.detail}`);
    }
    lines.push("");
  }
  return lines.join("\n");
}
function groupBy(arr, key) {
  return arr.reduce((acc, item) => {
    const k = key(item);
    if (!acc[k])
      acc[k] = [];
    acc[k].push(item);
    return acc;
  }, {});
}

// src/commands/run-lint.ts
var import_obsidian10 = require("obsidian");

// src/lint-engine.ts
init_files();
init_frontmatter();
async function runLint(app, settings) {
  var _a;
  const schema = await loadSchema(app, settings);
  if (!schema)
    return null;
  const paths = getVaultPaths(settings);
  const exemptPaths = buildExemptList(schema.exempt_paths, paths.vaultForge);
  const allFiles = getMarkdownFiles(app).filter(
    (f) => !isExempt(f.path, exemptPaths)
  );
  const validPatterns = getValidPatternNames(app, paths.patterns);
  const allResults = [];
  for (const file of allFiles) {
    const fileResults = await lintFile(app, file, schema, validPatterns);
    allResults.push(...fileResults);
  }
  const envelope = {
    vault_path: (_a = app.vault.adapter.basePath) != null ? _a : "",
    timestamp: (/* @__PURE__ */ new Date()).toISOString().substring(0, 19),
    schema_version: schema.meta.version,
    notes_scanned: allFiles.length
  };
  return {
    envelope,
    results: allResults,
    errors: allResults.filter((r) => r.severity === "error"),
    warnings: allResults.filter((r) => r.severity === "warning"),
    infos: allResults.filter((r) => r.severity === "info")
  };
}
async function lintFile(app, file, schema, validPatterns) {
  const note = await readNote(app, file);
  const results = [];
  if (!note || !note.hasFrontmatter) {
    results.push(newResult(file.path, "error", "no_frontmatter", "No frontmatter block found"));
    return results;
  }
  const fm = note.frontmatter;
  const content = await app.vault.read(file);
  results.push(...testRequiredFields(file.path, fm, schema.required_fields));
  results.push(...testBasicTypeFields(file.path, fm, schema.required_fields));
  results.push(...testEnumFields(file.path, fm, schema.required_fields));
  results.push(...testDateFields(file.path, fm, schema.required_fields));
  results.push(...testConditionalRules(file.path, fm, schema.required_fields));
  results.push(...testFieldTagConsistency(file.path, fm, schema.required_fields));
  const optFields = schema.optional_fields.filter((f) => isFieldPresent(fm, f.name));
  results.push(...testBasicTypeFields(file.path, fm, optFields));
  results.push(...testEnumFields(file.path, fm, optFields));
  results.push(...testDateFields(file.path, fm, optFields));
  results.push(...testConditionalRules(file.path, fm, optFields));
  results.push(...testPatternFieldValues(file.path, fm, optFields, validPatterns));
  results.push(...testTagNamespaces(file.path, fm, schema));
  results.push(...testInlineMetadata(file.path, content, schema));
  return results;
}
function testRequiredFields(path, fm, fields) {
  return fields.filter((f) => !isFieldPresent(fm, f.name)).map(
    (f) => newResult(path, f.severity, "required_field", `Missing required field: '${f.name}'`)
  );
}
function testBasicTypeFields(path, fm, fields) {
  const results = [];
  for (const field of fields) {
    if (!isFieldPresent(fm, field.name))
      continue;
    const val = fm[field.name];
    switch (field.type) {
      case "string":
        if (typeof val !== "string") {
          results.push(newResult(
            path,
            field.severity,
            "type_mismatch",
            `Field '${field.name}' must be a string`
          ));
        }
        break;
      case "boolean":
        if (typeof val !== "boolean") {
          results.push(newResult(
            path,
            field.severity,
            "type_mismatch",
            `Field '${field.name}' must be a boolean`
          ));
        }
        break;
      case "list":
        if (!Array.isArray(val)) {
          results.push(newResult(
            path,
            field.severity,
            "type_mismatch",
            `Field '${field.name}' must be a list`
          ));
        }
        break;
      case "version":
        if (typeof val !== "string" && typeof val !== "number") {
          results.push(newResult(
            path,
            field.severity,
            "type_mismatch",
            `Field '${field.name}' must be a version string or number`
          ));
        }
        break;
    }
  }
  return results;
}
function testEnumFields(path, fm, fields) {
  const results = [];
  for (const field of fields) {
    if (field.type !== "enum")
      continue;
    if (!isFieldPresent(fm, field.name))
      continue;
    if (!field.values)
      continue;
    const val = String(fm[field.name]);
    if (!field.values.includes(val)) {
      results.push(newResult(
        path,
        field.severity,
        "enum_value",
        `Field '${field.name}' value '${val}' not allowed. Valid: ${field.values.join(", ")}`
      ));
    }
  }
  return results;
}
function testDateFields(path, fm, fields) {
  const results = [];
  const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
  for (const field of fields) {
    if (field.type !== "date")
      continue;
    if (!isFieldPresent(fm, field.name))
      continue;
    const val = String(fm[field.name]);
    if (!dateRegex.test(val) || isNaN(Date.parse(val))) {
      results.push(newResult(
        path,
        field.severity,
        "date_format",
        `Field '${field.name}' value '${val}' does not match format yyyy-MM-dd`
      ));
      continue;
    }
    if (field.stale_after_days) {
      const parsed = new Date(val);
      const ageDays = (Date.now() - parsed.getTime()) / (1e3 * 60 * 60 * 24);
      if (ageDays > field.stale_after_days) {
        results.push(newResult(
          path,
          "warning",
          "stale_date",
          `Field '${field.name}' is ${Math.floor(ageDays)} days old (threshold: ${field.stale_after_days} days)`
        ));
      }
    }
  }
  return results;
}
function testConditionalRules(path, fm, fields) {
  var _a, _b, _c, _d, _e, _f;
  const results = [];
  for (const field of fields) {
    if (!((_a = field.lint_rules) == null ? void 0 : _a.length))
      continue;
    const fieldPresent = isFieldPresent(fm, field.name);
    for (const rule of field.lint_rules) {
      if (!rule.field)
        continue;
      if (!isFieldPresent(fm, rule.field))
        continue;
      const driverVal = String(fm[rule.field]);
      const severity = (_b = rule.severity) != null ? _b : "warning";
      if (rule.rule === "required_when") {
        const matchEquals = (_d = (_c = rule.equals) == null ? void 0 : _c.includes(driverVal)) != null ? _d : false;
        if (matchEquals && !fieldPresent) {
          results.push(newResult(
            path,
            severity,
            "required_when",
            `Field '${field.name}' is required when '${rule.field}' = '${driverVal}'`
          ));
        }
      }
      if (rule.rule === "forbidden_when") {
        const matchNotEquals = rule.not_equals ? !rule.not_equals.includes(driverVal) : false;
        const matchEquals = (_f = (_e = rule.equals) == null ? void 0 : _e.includes(driverVal)) != null ? _f : false;
        if ((matchNotEquals || matchEquals) && fieldPresent) {
          const label = rule.not_equals ? `not one of: ${rule.not_equals.join(", ")}` : `= '${driverVal}'`;
          results.push(newResult(
            path,
            severity,
            "forbidden_when",
            `Field '${field.name}' should not be present when '${rule.field}' is ${label}`
          ));
        }
      }
    }
  }
  return results;
}
function testFieldTagConsistency(path, fm, fields) {
  var _a, _b, _c;
  const results = [];
  const tags = getTags(fm);
  for (const field of fields) {
    if (!((_a = field.lint_rules) == null ? void 0 : _a.length))
      continue;
    for (const rule of field.lint_rules) {
      if (rule.rule !== "tag_consistency")
        continue;
      if (!rule.tag_namespace)
        continue;
      if (!isFieldPresent(fm, field.name))
        continue;
      const fieldVal = String(fm[field.name]).toLowerCase();
      const ns = rule.tag_namespace;
      const expected = `${ns}/${fieldVal}`;
      const nsTags = tags.filter((t) => t.startsWith(`${ns}/`));
      if (nsTags.length === 0) {
        results.push(newResult(
          path,
          (_b = rule.severity) != null ? _b : "warning",
          "tag_consistency",
          `Field '${field.name}' = '${fieldVal}' but no '${ns}/*' tag found. Expected: ${expected}`
        ));
      } else if (!tags.includes(expected)) {
        results.push(newResult(
          path,
          (_c = rule.severity) != null ? _c : "warning",
          "tag_consistency",
          `Field '${field.name}' = '${fieldVal}' but tag '${expected}' missing. Found: ${nsTags.join(", ")}`
        ));
      }
    }
  }
  return results;
}
function testPatternFieldValues(path, fm, fields, validPatterns) {
  const results = [];
  const patternField = fields.find((f) => f.name === "patterns");
  if (!patternField)
    return results;
  if (!isFieldPresent(fm, "patterns"))
    return results;
  const raw = fm["patterns"];
  const list = Array.isArray(raw) ? raw : [raw];
  const validSet = new Set(validPatterns.map((p) => p.toLowerCase()));
  for (const item of list) {
    if (item === null || item === void 0)
      continue;
    const val = String(item).trim();
    if (!val)
      continue;
    if (!validSet.has(val.toLowerCase())) {
      results.push(newResult(
        path,
        patternField.severity,
        "invalid_pattern_ref",
        `Field 'patterns' contains '${val}', which is not a valid pattern in System/Patterns/`
      ));
    }
  }
  return results;
}
function testTagNamespaces(path, fm, schema) {
  const results = [];
  const tags = getTags(fm);
  const { tag_rules } = schema;
  const allowedNs = new Set(tag_rules.allowed_namespaces);
  for (const tag of tags) {
    const slashIdx = tag.indexOf("/");
    if (slashIdx < 0) {
      results.push(newResult(
        path,
        tag_rules.severity,
        "tag_namespace",
        `Tag '${tag}' is not namespaced. Expected format: namespace/tag`
      ));
      continue;
    }
    const ns = tag.substring(0, slashIdx);
    if (tag_rules.unknown_tags !== "off" && !allowedNs.has(ns)) {
      results.push(newResult(
        path,
        "warning",
        "unknown_tag_namespace",
        `Tag namespace '${ns}' is not in allowed_namespaces`
      ));
    }
  }
  return results;
}
function testInlineMetadata(path, content, schema) {
  const results = [];
  const entries = extractInlineMetadataKeys(content);
  const schemaFieldNames = /* @__PURE__ */ new Set([
    ...schema.required_fields.map((f) => f.name.toLowerCase()),
    ...schema.optional_fields.map((f) => f.name.toLowerCase())
  ]);
  const inlineFieldNames = new Set(
    schema.inline_fields.map((f) => f.toLowerCase())
  );
  const allSchemaNames = [...schemaFieldNames];
  const allInlineNames = [...inlineFieldNames];
  const seen = /* @__PURE__ */ new Set();
  for (const entry of entries) {
    const dedupeKey = `${path}|${entry.key}`;
    if (seen.has(dedupeKey))
      continue;
    seen.add(dedupeKey);
    const keyLower = entry.key.toLowerCase();
    if (schemaFieldNames.has(keyLower)) {
      results.push(newResult(
        path,
        "error",
        "inline_is_schema_field",
        `Inline key '${entry.key}' is a schema frontmatter field \u2014 move to frontmatter (line ${entry.line})`
      ));
      continue;
    }
    if (inlineFieldNames.has(keyLower))
      continue;
    const [schemaDist, schemaMatch] = closestMatch(entry.key, allSchemaNames, 2);
    if (schemaDist <= 2 && schemaDist > 0) {
      results.push(newResult(
        path,
        "warning",
        "inline_fuzzy_schema",
        `Inline key '${entry.key}' looks like a typo of schema field '${schemaMatch}' (distance ${schemaDist}, line ${entry.line})`
      ));
      continue;
    }
    const [inlineDist, inlineMatch] = closestMatch(entry.key, allInlineNames, 2);
    if (inlineDist <= 2 && inlineDist > 0) {
      results.push(newResult(
        path,
        "warning",
        "inline_fuzzy_inline",
        `Inline key '${entry.key}' looks like a typo of inline field '${inlineMatch}' (distance ${inlineDist}, line ${entry.line})`
      ));
      continue;
    }
    results.push(newResult(
      path,
      "info",
      "inline_undocumented",
      `Inline key '${entry.key}' is undocumented \u2014 consider adding to inline_fields in schema.md (line ${entry.line})`
    ));
  }
  return results;
}
function extractInlineMetadataKeys(content) {
  const results = [];
  const lines = content.split(/\r?\n/);
  const inlinePattern = /^>?\s*([A-Za-z_][A-Za-z0-9_-]*)::\s*\S/;
  let inFrontmatter = false;
  let inFence = false;
  let lineNum = 0;
  for (const line of lines) {
    lineNum++;
    if (lineNum === 1 && /^---\s*$/.test(line)) {
      inFrontmatter = true;
      continue;
    }
    if (inFrontmatter && /^---\s*$/.test(line)) {
      inFrontmatter = false;
      continue;
    }
    if (inFrontmatter)
      continue;
    if (/^(```|~~~)/.test(line)) {
      inFence = !inFence;
      continue;
    }
    if (inFence)
      continue;
    const match = line.match(inlinePattern);
    if (match) {
      results.push({ key: match[1], line: lineNum });
    }
  }
  return results;
}
function newResult(file, severity, rule, message) {
  return { file, severity, rule, message };
}
function getValidPatternNames(app, patternsPath) {
  const folder = app.vault.getAbstractFileByPath(patternsPath);
  if (!folder)
    return [];
  const files = getMarkdownFiles(app, patternsPath);
  return files.map((f) => f.basename);
}
function closestMatch(input, candidates, maxDist) {
  let bestDist = maxDist + 1;
  let bestMatch = "";
  const inputLower = input.toLowerCase();
  for (const candidate of candidates) {
    if (Math.abs(inputLower.length - candidate.length) > maxDist)
      continue;
    const dist = levenshtein(inputLower, candidate, maxDist);
    if (dist < bestDist) {
      bestDist = dist;
      bestMatch = candidate;
    }
  }
  return [bestDist, bestMatch];
}
function levenshtein(a, b, maxDist) {
  if (a === b)
    return 0;
  if (a.length === 0)
    return b.length;
  if (b.length === 0)
    return a.length;
  let prev = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 1; i <= a.length; i++) {
    const curr = new Array(b.length + 1).fill(0);
    curr[0] = i;
    let rowMin = i;
    for (let j = 1; j <= b.length; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      curr[j] = Math.min(curr[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost);
      if (curr[j] < rowMin)
        rowMin = curr[j];
    }
    if (rowMin > maxDist)
      return maxDist + 1;
    prev = curr;
  }
  return prev[b.length];
}

// src/lint-writers.ts
var import_obsidian8 = require("obsidian");
init_files();
async function writeLintReportJson(app, settings, run) {
  const paths = getVaultPaths(settings);
  await ensureFolder(app, paths.exports);
  const report = {
    run: run.envelope,
    summary: {
      errors: run.errors.length,
      warnings: run.warnings.length,
      info: run.infos.length,
      notes_scanned: run.envelope.notes_scanned
    },
    results: run.results
  };
  const path = (0, import_obsidian8.normalizePath)(paths.lintReportJson);
  const existing = app.vault.getAbstractFileByPath(path);
  const content = JSON.stringify(report, null, 2);
  if (existing instanceof import_obsidian8.TFile) {
    await app.vault.modify(existing, content);
  } else {
    await app.vault.create(path, content);
  }
}
async function appendLintHistory(app, settings, run) {
  const paths = getVaultPaths(settings);
  await ensureFolder(app, paths.exports);
  const entry = {
    timestamp: run.envelope.timestamp,
    schema_version: run.envelope.schema_version,
    notes_scanned: run.envelope.notes_scanned,
    errors: run.errors.length,
    warnings: run.warnings.length,
    info: run.infos.length
  };
  let history = [];
  const histPath = (0, import_obsidian8.normalizePath)(paths.lintHistoryJson);
  const histFile = app.vault.getAbstractFileByPath(histPath);
  if (histFile instanceof import_obsidian8.TFile) {
    try {
      const raw = await app.vault.read(histFile);
      history = JSON.parse(raw);
      if (!Array.isArray(history))
        history = [];
    } catch (e) {
      history = [];
    }
  }
  history.push(entry);
  const cutoff = /* @__PURE__ */ new Date();
  cutoff.setDate(cutoff.getDate() - settings.lintHistoryRetentionDays);
  history = history.filter((e) => new Date(e.timestamp) >= cutoff);
  if (history.length > settings.lintHistoryMaxEntries) {
    history = history.slice(history.length - settings.lintHistoryMaxEntries);
  }
  const content = JSON.stringify(history, null, 2);
  if (histFile instanceof import_obsidian8.TFile) {
    await app.vault.modify(histFile, content);
  } else {
    await app.vault.create(histPath, content);
  }
}
async function writeLintRunNote(app, settings, run) {
  const paths = getVaultPaths(settings);
  await ensureFolder(app, paths.lintRuns);
  const safeTs = run.envelope.timestamp.replace(/[:.]/g, "-").replace("T", "_");
  const notePath = (0, import_obsidian8.normalizePath)(`${paths.lintRuns}/lint-run-${safeTs}.md`);
  const today = todayString();
  const content = buildLintRunNote(run, today, settings.lintFileLinks);
  const existing = app.vault.getAbstractFileByPath(notePath);
  if (existing instanceof import_obsidian8.TFile) {
    await app.vault.modify(existing, content);
  } else {
    await app.vault.create(notePath, content);
  }
  return notePath;
}
function summarizeLintMessage(rule, message) {
  if (rule === "inline_undocumented") {
    return "Inline keys are undocumented \u2014 consider adding to inline_fields in schema.md";
  }
  if (rule === "tag_namespace") {
    return "Tags are not namespaced. Expected format: namespace/tag";
  }
  return message;
}
function extractLintReason(rule, message) {
  if (rule === "inline_undocumented") {
    const match = message.match(/Inline key '([^']+)'/);
    return match ? `'${match[1]}'` : message;
  }
  if (rule === "tag_namespace") {
    const match = message.match(/Tag '([^']+)'/);
    return match ? `'${match[1]}'` : message;
  }
  return message;
}
function groupLintItems(items) {
  const groups = /* @__PURE__ */ new Map();
  const reasons = /* @__PURE__ */ new Map();
  const seenReasonFiles = /* @__PURE__ */ new Set();
  for (const item of items) {
    const summary = summarizeLintMessage(item.rule, item.message);
    const reasonLabel = extractLintReason(item.rule, item.message);
    const groupKey = `${item.rule}::${summary}`;
    const reasonKey = `${groupKey}::${reasonLabel}`;
    const reasonFileKey = `${reasonKey}::${item.file}`;
    let group = groups.get(groupKey);
    if (!group) {
      group = {
        rule: item.rule,
        summary,
        reasons: []
      };
      groups.set(groupKey, group);
    }
    let reason = reasons.get(reasonKey);
    if (!reason) {
      reason = {
        label: reasonLabel,
        files: []
      };
      reasons.set(reasonKey, reason);
      group.reasons.push(reason);
    }
    if (!seenReasonFiles.has(reasonFileKey)) {
      seenReasonFiles.add(reasonFileKey);
      reason.files.push(item.file);
    }
  }
  return [...groups.values()];
}
function buildLintRunNote(run, today, fileLinks) {
  const lines = [
    "---",
    "type: reference",
    "status: complete",
    "tags:",
    "  - meta/vault-lint",
    `created: ${today}`,
    `updated: ${today}`,
    "ai_private: false",
    "review_cycle: never",
    "---",
    "",
    `schema_version:: "${run.envelope.schema_version}"`,
    `runtime:: ${run.envelope.timestamp}`,
    `notes_scanned:: ${run.envelope.notes_scanned}`,
    `errors:: ${run.errors.length}`,
    `warnings:: ${run.warnings.length}`,
    `infos:: ${run.infos.length}`,
    "",
    "# Lint Run",
    "",
    "## Summary",
    "",
    "| Severity | Count |",
    "|----------|-------|",
    `| \u{1F534} Error   | ${run.errors.length}   |`,
    `| \u{1F7E1} Warning | ${run.warnings.length} |`,
    `| \u{1F535} Info    | ${run.infos.length}    |`,
    ""
  ];
  for (const { label, items } of [
    { label: "\u{1F534} Errors", items: run.errors },
    { label: "\u{1F7E1} Warnings", items: run.warnings },
    { label: "\u{1F535} Info", items: run.infos }
  ]) {
    if (items.length === 0)
      continue;
    lines.push(`## ${label}`, "");
    for (const group of groupLintItems(items)) {
      lines.push(`### \`[${group.rule}]\``);
      lines.push("");
      lines.push(group.summary);
      lines.push("");
      for (const reason of group.reasons) {
        lines.push(`#### ${reason.label}`);
        lines.push("");
        for (const file of reason.files) {
          const fileRef = fileLinks ? `[[${file}]]` : `\`${file}\``;
          lines.push(`- ${fileRef}`);
        }
        lines.push("");
      }
    }
  }
  return lines.join("\n");
}

// src/commands/repair.ts
var import_obsidian9 = require("obsidian");
init_files();
async function runVaultRepair(plugin) {
  var _a;
  const { app, settings } = plugin;
  const paths = getVaultPaths(settings);
  const reportFile = app.vault.getAbstractFileByPath(paths.lintReportJson);
  if (!(reportFile instanceof import_obsidian9.TFile)) {
    new import_obsidian9.Notice("Vault Forge: No lint report found. Run Vault Lint first.", 5e3);
    return;
  }
  let report;
  try {
    const raw = await app.vault.read(reportFile);
    report = JSON.parse(raw);
  } catch (e) {
    new import_obsidian9.Notice("Vault Forge: Could not parse lint-report.json.", 5e3);
    return;
  }
  const errors = ((_a = report.results) != null ? _a : []).filter(
    (r) => r.severity === "error" || r.severity === "warning" && (r.rule === "required_field" || r.rule === "type_mismatch" || r.rule === "enum_value")
  );
  if (errors.length === 0) {
    new import_obsidian9.Notice("Vault Forge: No errors in lint report \u2014 nothing to repair.", 4e3);
    return;
  }
  const schema = await loadSchema(app, settings);
  if (!schema) {
    new import_obsidian9.Notice("Vault Forge: Could not load schema.md \u2014 repair aborted.", 5e3);
    return;
  }
  const byFile = /* @__PURE__ */ new Map();
  for (const error of errors) {
    if (!byFile.has(error.file))
      byFile.set(error.file, []);
    byFile.get(error.file).push(error);
  }
  new VaultRepairModal(app, plugin, schema, byFile).open();
}
var VaultRepairModal = class extends import_obsidian9.Modal {
  constructor(app, plugin, schema, byFile) {
    super(app);
    this.currentIndex = 0;
    this.ops = [];
    this.skippedCount = 0;
    this.plugin = plugin;
    this.schema = schema;
    this.byFile = byFile;
    this.fileList = [...byFile.keys()];
  }
  onOpen() {
    this.renderCurrentFile();
  }
  renderCurrentFile() {
    var _a, _b;
    const { contentEl } = this;
    contentEl.empty();
    if (this.currentIndex >= this.fileList.length) {
      this.renderFinish();
      return;
    }
    const filePath = this.fileList[this.currentIndex];
    const fileErrors = (_a = this.byFile.get(filePath)) != null ? _a : [];
    const total = this.fileList.length;
    const current = this.currentIndex + 1;
    contentEl.createEl("h2", { text: `Vault Repair (${current} of ${total})` });
    contentEl.createEl("p", {
      text: filePath,
      cls: "vault-forge-schema-path"
    });
    contentEl.createEl("h3", { text: "Issues" });
    const errorList = contentEl.createEl("ul", { cls: "vault-forge-error-list" });
    for (const e of fileErrors) {
      const prefix = e.severity === "warning" ? "\u26A0\uFE0F" : "\u{1F534}";
      errorList.createEl("li", { text: `${prefix} [${e.rule}] ${e.message}` });
    }
    const fieldsToFix = this.getFieldsToFix(fileErrors);
    const fieldValues = /* @__PURE__ */ new Map();
    if (fieldsToFix.length > 0) {
      contentEl.createEl("h3", { text: "Fix" });
      for (const fieldName of fieldsToFix) {
        const field = (_b = this.schema.required_fields.find((f) => f.name === fieldName)) != null ? _b : this.schema.optional_fields.find((f) => f.name === fieldName);
        if (!field)
          continue;
        if (field.type === "enum" && field.values) {
          const suggestion = this.getSuggestion(fieldName, fileErrors);
          const initialVal = suggestion ? String(suggestion) : field.values[0];
          fieldValues.set(fieldName, initialVal);
          new import_obsidian9.Setting(contentEl).setName(fieldName).setDesc(`Valid: ${field.values.join(", ")}`).addDropdown((dd) => {
            for (const v of field.values) {
              dd.addOption(v, v);
            }
            dd.setValue(initialVal);
            dd.onChange((val) => fieldValues.set(fieldName, val));
          });
        } else if (field.type === "boolean") {
          const suggestion = this.getSuggestion(fieldName, fileErrors);
          const initialVal = suggestion !== null ? String(suggestion) : "false";
          fieldValues.set(fieldName, initialVal === "true");
          new import_obsidian9.Setting(contentEl).setName(fieldName).addDropdown((dd) => {
            dd.addOption("false", "false");
            dd.addOption("true", "true");
            dd.setValue(initialVal);
            dd.onChange((val) => fieldValues.set(fieldName, val === "true"));
          });
        } else if (field.type === "date") {
          const suggestion = this.getSuggestion(fieldName, fileErrors);
          const initialVal = suggestion ? String(suggestion) : todayString();
          fieldValues.set(fieldName, initialVal);
          new import_obsidian9.Setting(contentEl).setName(fieldName).setDesc("Format: yyyy-MM-dd").addText((t) => {
            t.setPlaceholder("yyyy-MM-dd");
            t.setValue(initialVal);
            t.onChange((val) => fieldValues.set(fieldName, val));
          });
        } else if (field.type === "list" && fieldName === "tags") {
          new import_obsidian9.Setting(contentEl).setName("tags").setDesc(`Comma-separated. Namespaces: ${this.schema.tag_rules.allowed_namespaces.join(", ")}`).addText((t) => {
            t.setPlaceholder("topic/identity, skill/governance");
            t.onChange((val) => {
              fieldValues.set("tags", val.split(",").map((s) => s.trim()).filter(Boolean));
            });
          });
        } else {
          const suggestion = this.getSuggestion(fieldName, fileErrors);
          if (suggestion)
            fieldValues.set(fieldName, suggestion);
          new import_obsidian9.Setting(contentEl).setName(fieldName).addText((t) => {
            if (suggestion)
              t.setValue(String(suggestion));
            t.onChange((val) => fieldValues.set(fieldName, val));
          });
        }
      }
    }
    const buttonRow = contentEl.createDiv("vault-forge-button-row");
    const fixBtn = buttonRow.createEl("button", {
      text: fieldsToFix.length > 0 ? "Fix & Continue" : "Skip",
      cls: fieldsToFix.length > 0 ? "mod-cta" : ""
    });
    fixBtn.addEventListener("click", () => {
      for (const [fieldName, value] of fieldValues) {
        if (fieldName === "tags" && Array.isArray(value)) {
          for (const tag of value) {
            this.ops.push({ op: "add_tag", target: filePath, tag });
          }
        } else if (value !== "" && value !== void 0) {
          this.ops.push({ op: "set_field", target: filePath, field: fieldName, value });
        }
      }
      this.currentIndex++;
      this.renderCurrentFile();
    });
    if (fieldsToFix.length > 0) {
      const skipBtn = buttonRow.createEl("button", { text: "Skip File" });
      skipBtn.addEventListener("click", () => {
        this.skippedCount++;
        this.currentIndex++;
        this.renderCurrentFile();
      });
    }
    const cancelBtn = buttonRow.createEl("button", { text: "Cancel All" });
    cancelBtn.addEventListener("click", () => this.close());
  }
  renderFinish() {
    const { contentEl } = this;
    contentEl.empty();
    contentEl.createEl("h2", { text: "Repair Summary" });
    if (this.ops.length === 0) {
      contentEl.createEl("p", { text: "No operations collected \u2014 nothing to patch." });
      const closeBtn = contentEl.createEl("button", { text: "Close" });
      closeBtn.addEventListener("click", () => this.close());
      return;
    }
    contentEl.createEl("p", {
      text: `${this.ops.length} operation(s) collected across ${this.fileList.length - this.skippedCount} file(s).`
    });
    if (this.skippedCount > 0) {
      contentEl.createEl("p", { text: `${this.skippedCount} file(s) skipped.`, cls: "vault-forge-error-note" });
    }
    contentEl.createEl("p", {
      text: `The repair patch will be written to ${getVaultPaths(this.plugin.settings).patchFile}.`,
      cls: "vault-forge-backup-notice"
    });
    const buttonRow = contentEl.createDiv("vault-forge-button-row");
    const writeAndApplyBtn = buttonRow.createEl("button", {
      text: "Write Patch & Apply",
      cls: "mod-cta"
    });
    writeAndApplyBtn.addEventListener("click", async () => {
      this.close();
      await this.writePatch();
      await runApplyPatch(this.plugin);
    });
    const writeBtn = buttonRow.createEl("button", { text: "Write Patch Only" });
    writeBtn.addEventListener("click", async () => {
      this.close();
      await this.writePatch();
      new import_obsidian9.Notice("Vault Forge: Repair patch written. Run Apply Vault Patch when ready.", 5e3);
    });
    const cancelBtn = buttonRow.createEl("button", { text: "Cancel" });
    cancelBtn.addEventListener("click", () => this.close());
  }
  async writePatch() {
    const paths = getVaultPaths(this.plugin.settings);
    const today = todayString();
    const existingPatch = this.app.vault.getAbstractFileByPath(paths.patchFile);
    if (existingPatch instanceof import_obsidian9.TFile) {
      const existing2 = await this.app.vault.read(existingPatch);
      const hasOps = existing2.includes("op:") || existing2.includes("operations:");
      if (hasOps) {
        new import_obsidian9.Notice(
          "Vault Forge: Overwriting existing patch file \u2014 previous operations will be replaced.",
          5e3
        );
      }
    }
    const patch = {
      meta: {
        generated_at: (/* @__PURE__ */ new Date()).toISOString(),
        description: "Repair pass \u2014 interactive fix of lint errors",
        schema_version: this.schema.meta.version,
        source: "Vault Forge \u2014 Vault Repair",
        contains_schema_changes: false
      },
      operations: this.ops
    };
    const lines = [
      "meta:",
      `  generated_at: ${patch.meta.generated_at}`,
      `  description: "${patch.meta.description}"`,
      `  schema_version: "${patch.meta.schema_version}"`,
      `  source: "${patch.meta.source}"`,
      `  contains_schema_changes: false`,
      "",
      "operations:"
    ];
    for (const op of this.ops) {
      lines.push(`  - op: ${op.op}`);
      lines.push(`    target: "${op.target}"`);
      if (op.field)
        lines.push(`    field: ${op.field}`);
      if (op.tag)
        lines.push(`    tag: ${op.tag}`);
      if (op.value !== void 0) {
        if (typeof op.value === "string") {
          lines.push(`    value: "${op.value}"`);
        } else if (typeof op.value === "boolean") {
          lines.push(`    value: ${op.value}`);
        } else {
          lines.push(`    value: ${op.value}`);
        }
      }
    }
    const content = [
      "---",
      "type: procedure",
      "status: draft",
      "tags:",
      "  - tool/vault-forge",
      `created: ${today}`,
      `updated: ${today}`,
      "ai_private: false",
      "review_cycle: never",
      "---",
      "",
      "# Vault Patch",
      "",
      "Patch generated by Vault Forge Repair.",
      "",
      "## Patch",
      "",
      "```yaml",
      ...lines,
      "```",
      ""
    ].join("\n");
    const patchPath = paths.patchFile;
    const patchFolder = patchPath.includes("/") ? patchPath.substring(0, patchPath.lastIndexOf("/")) : "";
    if (patchFolder)
      await ensureFolder(this.app, patchFolder);
    const existing = this.app.vault.getAbstractFileByPath(patchPath);
    if (existing instanceof import_obsidian9.TFile) {
      await this.app.vault.modify(existing, content);
    } else {
      await this.app.vault.create(patchPath, content);
    }
  }
  getFieldsToFix(errors) {
    const fields = /* @__PURE__ */ new Set();
    const hasNoFrontmatter = errors.some((e) => e.rule === "no_frontmatter");
    if (hasNoFrontmatter) {
      for (const field of this.schema.required_fields) {
        fields.add(field.name);
      }
      return [...fields];
    }
    for (const e of errors) {
      if (e.rule === "required_field") {
        const m = e.message.match(/Missing required field: '([\w_]+)'/);
        if (m)
          fields.add(m[1]);
      } else if (e.rule === "enum_value") {
        const m = e.message.match(/Field '([\w_]+)'/);
        if (m)
          fields.add(m[1]);
      } else if (e.rule === "required_when") {
        const m = e.message.match(/Field '([\w_]+)'/);
        if (m)
          fields.add(m[1]);
      }
    }
    return [...fields];
  }
  getSuggestion(fieldName, errors) {
    var _a, _b, _c;
    const cacheDefault = (_a = this.plugin.schemaCache) == null ? void 0 : _a.getDefaultValue(fieldName);
    if (fieldName === "status") {
      const statusErr = errors.find((e) => e.rule === "enum_value" && e.message.includes("'status'"));
      if (statusErr) {
        const values = (_b = this.plugin.schemaCache) == null ? void 0 : _b.getEnumValues("status");
        return (values == null ? void 0 : values.includes("active")) ? "active" : (_c = values == null ? void 0 : values[0]) != null ? _c : cacheDefault;
      }
    }
    return cacheDefault != null ? cacheDefault : null;
  }
  onClose() {
    this.contentEl.empty();
  }
};

// src/commands/run-lint.ts
async function runVaultLint(plugin) {
  const { app, settings } = plugin;
  const noteCount = app.vault.getMarkdownFiles().length;
  const estimatedSeconds = Math.max(3, Math.ceil(noteCount / 200));
  new import_obsidian10.Notice(
    `Vault Forge: Running lint on ${noteCount} notes\u2026 (may take ~${estimatedSeconds}s on large vaults)`,
    estimatedSeconds * 1e3
  );
  const result = await runLint(app, settings);
  if (!result) {
    new import_obsidian10.Notice(
      "Vault Forge: Could not load schema.md \u2014 lint aborted. Run Validate Schema to diagnose.",
      6e3
    );
    return null;
  }
  await writeLintReportJson(app, settings, result);
  await appendLintHistory(app, settings, result);
  const runNotePath = await writeLintRunNote(app, settings, result);
  new LintResultsModal(app, plugin, result, runNotePath).open();
  return result;
}
function summarizeLintMessage2(rule, message) {
  if (rule === "inline_undocumented") {
    return "Inline keys are undocumented \u2014 consider adding to inline_fields in schema.md";
  }
  if (rule === "tag_namespace") {
    return "Tags are not namespaced. Expected format: namespace/tag";
  }
  return message;
}
function extractLintReason2(rule, message) {
  if (rule === "inline_undocumented") {
    const match = message.match(/Inline key '([^']+)'/);
    return match ? `'${match[1]}'` : message;
  }
  if (rule === "tag_namespace") {
    const match = message.match(/Tag '([^']+)'/);
    return match ? `'${match[1]}'` : message;
  }
  return message;
}
function groupLintItems2(items) {
  const groups = /* @__PURE__ */ new Map();
  const reasons = /* @__PURE__ */ new Map();
  const seenReasonFiles = /* @__PURE__ */ new Set();
  for (const item of items) {
    const summary = summarizeLintMessage2(item.rule, item.message);
    const reasonLabel = extractLintReason2(item.rule, item.message);
    const groupKey = `${item.rule}::${summary}`;
    const reasonKey = `${groupKey}::${reasonLabel}`;
    const reasonFileKey = `${reasonKey}::${item.file}`;
    let group = groups.get(groupKey);
    if (!group) {
      group = {
        rule: item.rule,
        summary,
        reasons: []
      };
      groups.set(groupKey, group);
    }
    let reason = reasons.get(reasonKey);
    if (!reason) {
      reason = {
        label: reasonLabel,
        files: []
      };
      reasons.set(reasonKey, reason);
      group.reasons.push(reason);
    }
    if (!seenReasonFiles.has(reasonFileKey)) {
      seenReasonFiles.add(reasonFileKey);
      reason.files.push(item.file);
    }
  }
  return [...groups.values()];
}
var LintResultsModal = class extends import_obsidian10.Modal {
  constructor(app, plugin, result, runNotePath) {
    super(app);
    this.plugin = plugin;
    this.result = result;
    this.runNotePath = runNotePath;
  }
  onOpen() {
    const { contentEl } = this;
    contentEl.empty();
    const r = this.result;
    const failed = r.errors.length > 0 || this.plugin.settings.lintStrictMode && r.warnings.length > 0;
    contentEl.createEl("h2", {
      text: failed ? "\u274C Vault Lint \u2014 Failed" : "\u2705 Vault Lint \u2014 Passed"
    });
    const summaryEl = contentEl.createDiv("vault-forge-lint-summary");
    summaryEl.createEl("div", {
      text: `${r.errors.length} errors`
    });
    summaryEl.createEl("div", {
      text: `${r.warnings.length} warnings`
    });
    summaryEl.createEl("div", {
      text: `${r.infos.length} info`
    });
    summaryEl.createEl("br");
    summaryEl.createEl("div", {
      text: `${r.envelope.notes_scanned} notes scanned`
    });
    if (r.errors.length > 0) {
      contentEl.createEl("h3", { text: "Errors" });
      for (const group of groupLintItems2(r.errors)) {
        contentEl.createEl("div", {
          text: `[${group.rule}]`,
          cls: "vault-forge-lint-rule"
        });
        contentEl.createEl("div", {
          text: group.summary,
          cls: "vault-forge-lint-message"
        });
        for (const reason of group.reasons) {
          contentEl.createEl("h4", {
            text: reason.label,
            cls: "vault-forge-lint-reason"
          });
          const list = contentEl.createEl("ul", {
            cls: "vault-forge-lint-list"
          });
          for (const file of reason.files) {
            list.createEl("li", {
              text: file
            });
          }
        }
      }
    }
    if (r.warnings.length > 0) {
      contentEl.createEl("h3", { text: "Warnings" });
      for (const group of groupLintItems2(r.warnings)) {
        contentEl.createEl("div", {
          text: `[${group.rule}]`,
          cls: "vault-forge-lint-rule"
        });
        contentEl.createEl("div", {
          text: group.summary,
          cls: "vault-forge-lint-message"
        });
        for (const reason of group.reasons) {
          contentEl.createEl("h4", {
            text: reason.label,
            cls: "vault-forge-lint-reason"
          });
          const list = contentEl.createEl("ul", {
            cls: "vault-forge-lint-list"
          });
          for (const file of reason.files) {
            list.createEl("li", {
              text: file
            });
          }
        }
      }
    }
    if (r.infos.length > 0) {
      contentEl.createEl("h3", { text: "Info" });
      for (const group of groupLintItems2(r.infos)) {
        contentEl.createEl("div", {
          text: `[${group.rule}]`,
          cls: "vault-forge-lint-rule"
        });
        contentEl.createEl("div", {
          text: group.summary,
          cls: "vault-forge-lint-message"
        });
        for (const reason of group.reasons) {
          contentEl.createEl("h4", {
            text: reason.label,
            cls: "vault-forge-lint-reason"
          });
          const list = contentEl.createEl("ul", {
            cls: "vault-forge-lint-list"
          });
          for (const file of reason.files) {
            list.createEl("li", {
              text: file
            });
          }
        }
      }
    }
    const buttonRow = contentEl.createDiv("vault-forge-button-row");
    const viewBtn = buttonRow.createEl("button", {
      text: "View Lint Run Note",
      cls: "mod-cta"
    });
    viewBtn.addEventListener("click", () => {
      this.close();
      this.app.workspace.openLinkText(this.runNotePath, "", false);
    });
    if (r.errors.length > 0) {
      const repairBtn = buttonRow.createEl("button", { text: "Open Vault Repair" });
      repairBtn.addEventListener("click", () => {
        this.close();
        runVaultRepair(this.plugin);
      });
    }
    const closeBtn = buttonRow.createEl("button", { text: "Close" });
    closeBtn.addEventListener("click", () => this.close());
  }
  onClose() {
    this.contentEl.empty();
  }
};

// src/commands/apply-patch.ts
init_files();
async function runApplyPatch(plugin) {
  var _a;
  const { app, settings } = plugin;
  const paths = getVaultPaths(settings);
  let patchFile = await loadPatchFile(app, paths.patchFile);
  if (!patchFile) {
    const created = await createPatchTemplateIfMissing(app, paths.patchFile);
    if (created) {
      new import_obsidian11.Notice(
        `Vault Forge: Created patch note at ${paths.patchFile}. Add operations, then run Apply Vault Patch again.`,
        7e3
      );
      return;
    }
    new import_obsidian11.Notice(
      `Vault Forge: Patch file not found or has no YAML block at ${paths.patchFile}`,
      7e3
    );
    return;
  }
  if (patchFile.operations.length === 0) {
    new import_obsidian11.Notice("Vault Forge: Patch file has no operations.", 4e3);
    return;
  }
  new import_obsidian11.Notice("Vault Forge: Running dry pass\u2026", 2e3);
  const dryResult = await applyPatch(
    app,
    settings,
    patchFile,
    paths.patchFile,
    true
  );
  new PatchConfirmModal(app, plugin, (_a = patchFile.meta.description) != null ? _a : "", dryResult, async () => {
    new import_obsidian11.Notice("Vault Forge: Applying patch\u2026", 2e3);
    const applyResult = await applyPatch(
      app,
      settings,
      patchFile,
      paths.patchFile,
      false
    );
    await writeRestoreManifest(app, settings, applyResult);
    await archivePatchFile(app, settings, applyResult);
    const reportPath = await writePatchReport(app, settings, applyResult);
    const changed = applyResult.results.filter((r) => r.status === "changed").length;
    const errors = applyResult.results.filter((r) => r.status === "error").length;
    if (errors > 0) {
      new import_obsidian11.Notice(
        `Vault Forge: Patch applied with ${errors} error(s). Changed: ${changed}. See report.`,
        7e3
      );
    } else {
      new import_obsidian11.Notice(
        `Vault Forge: Patch applied. ${changed} file(s) changed.`,
        5e3
      );
    }
    const reportFile = app.vault.getAbstractFileByPath((0, import_obsidian11.normalizePath)(reportPath));
    if (reportFile) {
      app.workspace.openLinkText(reportPath, "", false);
    }
    if (settings.patchAutoLintAfterApply) {
      await runVaultLint(plugin);
    }
  }).open();
}
async function createPatchTemplateIfMissing(app, patchPath) {
  const normalizedPath = (0, import_obsidian11.normalizePath)(patchPath);
  const existing = app.vault.getAbstractFileByPath(normalizedPath);
  if (existing instanceof import_obsidian11.TFile)
    return false;
  const folder = normalizedPath.includes("/") ? normalizedPath.substring(0, normalizedPath.lastIndexOf("/")) : "";
  if (folder)
    await ensureFolder(app, folder);
  const today = todayString();
  const content = [
    "---",
    "type: procedure",
    "status: draft",
    "tags:",
    "  - tool/vault-forge",
    `created: ${today}`,
    `updated: ${today}`,
    "ai_private: false",
    "review_cycle: never",
    "---",
    "",
    "# Vault Patch",
    "",
    "Patch file for Vault Forge.",
    "",
    "## Patch",
    "",
    "```yaml",
    "meta:",
    "  description: Manual vault patch",
    "",
    "operations: []",
    "```",
    ""
  ].join("\n");
  await app.vault.create(normalizedPath, content);
  return true;
}
var PatchConfirmModal = class extends import_obsidian11.Modal {
  constructor(app, plugin, description, dryResult, onConfirm) {
    super(app);
    this.plugin = plugin;
    this.description = description;
    this.dryResult = dryResult;
    this.onConfirm = onConfirm;
  }
  onOpen() {
    const { contentEl } = this;
    contentEl.empty();
    const changed = this.dryResult.results.filter((r) => r.status === "changed");
    const skipped = this.dryResult.results.filter((r) => r.status === "skipped");
    const errors = this.dryResult.results.filter((r) => r.status === "error");
    contentEl.createEl("h2", { text: "Apply Vault Patch" });
    if (this.description) {
      contentEl.createEl("p", {
        text: this.description,
        cls: "vault-forge-patch-description"
      });
    }
    const summary = contentEl.createDiv("vault-forge-patch-summary");
    const countEl = summary.createDiv("vault-forge-patch-counts");
    countEl.createSpan({
      text: `${changed.length} changes`,
      cls: changed.length > 0 ? "vault-forge-count-changed" : "vault-forge-count-zero"
    });
    countEl.createSpan({ text: "  |  " });
    countEl.createSpan({
      text: `${skipped.length} skipped`,
      cls: "vault-forge-count-skipped"
    });
    countEl.createSpan({ text: "  |  " });
    countEl.createSpan({
      text: `${errors.length} errors`,
      cls: errors.length > 0 ? "vault-forge-count-error" : "vault-forge-count-zero"
    });
    if (errors.length > 0) {
      contentEl.createEl("h3", { text: "Errors" });
      const errorList = contentEl.createEl("ul", { cls: "vault-forge-error-list" });
      for (const r of errors.slice(0, 10)) {
        errorList.createEl("li", { text: `[${r.op}] ${r.file} \u2014 ${r.detail}` });
      }
      if (errors.length > 10) {
        errorList.createEl("li", { text: `\u2026and ${errors.length - 10} more` });
      }
      contentEl.createEl("p", {
        text: "Errors will not be applied. You can still proceed with the successful operations.",
        cls: "vault-forge-error-note"
      });
    }
    if (changed.length > 0) {
      contentEl.createEl("h3", { text: "Changes" });
      const changeList = contentEl.createEl("ul", { cls: "vault-forge-change-list" });
      for (const r of changed.slice(0, 20)) {
        changeList.createEl("li", { text: `${r.file} \u2014 ${r.detail}` });
      }
      if (changed.length > 20) {
        changeList.createEl("li", {
          text: `\u2026and ${changed.length - 20} more`,
          cls: "vault-forge-more"
        });
      }
    }
    if (changed.length === 0 && errors.length === 0) {
      contentEl.createEl("p", {
        text: "No changes needed \u2014 vault already matches the patch.",
        cls: "vault-forge-no-changes"
      });
    }
    if (this.plugin.settings.patchBackupEnabled && changed.length > 0) {
      contentEl.createEl("p", {
        text: `Backups will be written to System/VaultForge/Patches/Backups/`,
        cls: "vault-forge-backup-notice"
      });
    }
    const buttonRow = contentEl.createDiv("vault-forge-button-row");
    if (changed.length > 0) {
      const applyBtn = buttonRow.createEl("button", {
        text: "Apply",
        cls: "mod-cta"
      });
      applyBtn.addEventListener("click", async () => {
        this.close();
        await this.onConfirm();
      });
    }
    const cancelBtn = buttonRow.createEl("button", { text: "Cancel" });
    cancelBtn.addEventListener("click", () => this.close());
  }
  onClose() {
    this.contentEl.empty();
  }
};

// src/commands/validate-schema.ts
var import_obsidian12 = require("obsidian");
async function runValidateSchema(plugin) {
  const { app, settings } = plugin;
  const paths = getVaultPaths(settings);
  const file = app.vault.getAbstractFileByPath(paths.schemaMd);
  if (!(file instanceof import_obsidian12.TFile)) {
    new import_obsidian12.Notice(
      `Vault Forge: schema.md not found at ${paths.schemaMd}`,
      6e3
    );
    return;
  }
  let raw;
  try {
    raw = await app.vault.read(file);
  } catch (e) {
    new import_obsidian12.Notice("Vault Forge: Could not read schema.md.", 5e3);
    return;
  }
  const issues = validateSchemaNote(raw);
  if (!issues.some((i) => i.severity === "error")) {
    await plugin.schemaCache.refresh();
  }
  new ValidateSchemaModal(app, plugin, issues, paths.schemaMd).open();
}
var ValidateSchemaModal = class extends import_obsidian12.Modal {
  constructor(app, plugin, issues, schemaPath) {
    super(app);
    this.plugin = plugin;
    this.issues = issues;
    this.schemaPath = schemaPath;
  }
  onOpen() {
    const { contentEl } = this;
    contentEl.empty();
    const errors = this.issues.filter((i) => i.severity === "error");
    const warnings = this.issues.filter((i) => i.severity === "warning");
    const passed = errors.length === 0;
    contentEl.createEl("h2", {
      text: passed ? "\u2705 Schema Valid" : "\u{1F534} Schema Errors Found"
    });
    contentEl.createEl("p", {
      text: `Schema: ${this.schemaPath}`,
      cls: "vault-forge-schema-path"
    });
    if (passed && warnings.length === 0) {
      contentEl.createEl("p", {
        text: "schema.md is well-formed. All required sections are present and parseable.",
        cls: "vault-forge-success-msg"
      });
    }
    if (errors.length > 0) {
      contentEl.createEl("h3", { text: "Errors" });
      const list = contentEl.createEl("ul", { cls: "vault-forge-lint-list" });
      for (const issue of errors) {
        list.createEl("li", { text: issue.message });
      }
    }
    if (warnings.length > 0) {
      contentEl.createEl("h3", { text: "Warnings" });
      const list = contentEl.createEl("ul", { cls: "vault-forge-lint-list" });
      for (const issue of warnings) {
        list.createEl("li", { text: issue.message });
      }
    }
    const buttonRow = contentEl.createDiv("vault-forge-button-row");
    const openBtn = buttonRow.createEl("button", {
      text: "Open schema.md",
      cls: passed ? "mod-cta" : ""
    });
    openBtn.addEventListener("click", () => {
      this.close();
      this.app.workspace.openLinkText(this.schemaPath, "", false);
    });
    const closeBtn = buttonRow.createEl("button", { text: "Close" });
    closeBtn.addEventListener("click", () => this.close());
  }
  onClose() {
    this.contentEl.empty();
  }
};

// src/commands/normalize.ts
var import_obsidian13 = require("obsidian");
init_frontmatter();
init_files();
async function runNormalizeTags(plugin) {
  var _a;
  const { app, settings } = plugin;
  const paths = getVaultPaths(settings);
  const schema = await loadSchema(app, settings);
  const exemptPaths = buildExemptList((_a = schema == null ? void 0 : schema.exempt_paths) != null ? _a : [], paths.vaultForge);
  const files = getMarkdownFiles(app).filter(
    (f) => !isExempt(f.path, exemptPaths)
  );
  new import_obsidian13.Notice("Vault Forge: Scanning tags\u2026", 2e3);
  const dryResults = await normalizeTagsPass(app, settings, files, true);
  const candidates = dryResults.filter((r) => r.changed);
  if (candidates.length === 0) {
    new import_obsidian13.Notice("Vault Forge: All tags already normalized \u2014 no changes needed.", 4e3);
    return;
  }
  new NormalizeConfirmModal(
    app,
    plugin,
    "Normalize Tags",
    `${candidates.length} file(s) have tags to normalize.`,
    candidates,
    async () => {
      const applyResults = await normalizeTagsPass(app, settings, files, false);
      const changed = applyResults.filter((r) => r.changed).length;
      new import_obsidian13.Notice(`Vault Forge: Normalized tags in ${changed} file(s).`, 4e3);
    }
  ).open();
}
async function normalizeTagsPass(app, settings, files, dryRun) {
  const paths = getVaultPaths(settings);
  const results = [];
  for (const file of files) {
    const note = await readNote(app, file);
    if (!note || !note.hasFrontmatter)
      continue;
    const originalTags = getTags(note.frontmatter);
    const converted = originalTags.map(convertTagSeparator).filter((t) => !isInvalidTag(t));
    const normalized = normalizeTags(converted);
    const originalStr = originalTags.join("|");
    const normalizedStr = normalized.join("|");
    if (originalStr === normalizedStr)
      continue;
    const removedCount = originalTags.length - converted.length;
    const convertedCount = originalTags.filter(
      (t, i) => convertTagSeparator(t) !== t
    ).length;
    const details = [];
    if (convertedCount > 0)
      details.push(`${convertedCount} separator(s) fixed`);
    if (removedCount > 0)
      details.push(`${removedCount} invalid tag(s) removed`);
    if (originalStr !== normalizedStr)
      details.push("sorted/deduped");
    if (!dryRun) {
      await backupNote(app, file, paths.patchBackups);
      setTags(note.frontmatter, normalized);
      await writeNote(app, note);
    }
    results.push({
      file: file.path,
      changed: true,
      detail: details.join(", ")
    });
  }
  return results;
}
async function runNormalizeFrontmatter(plugin) {
  var _a;
  const { app, settings } = plugin;
  const paths = getVaultPaths(settings);
  const schema = await loadSchema(app, settings);
  const exemptPaths = [
    ...(_a = schema == null ? void 0 : schema.exempt_paths) != null ? _a : [],
    paths.vaultForge
  ];
  const files = getMarkdownFiles(app).filter(
    (f) => !isExempt(f.path, exemptPaths)
  );
  new import_obsidian13.Notice("Vault Forge: Scanning frontmatter\u2026", 2e3);
  const dryResults = await normalizeFrontmatterPass(app, settings, files, true, plugin);
  const candidates = dryResults.filter((r) => r.changed);
  if (candidates.length === 0) {
    new import_obsidian13.Notice("Vault Forge: All frontmatter already normalized \u2014 no changes needed.", 4e3);
    return;
  }
  new NormalizeConfirmModal(
    app,
    plugin,
    "Normalize Frontmatter",
    `${candidates.length} file(s) have frontmatter to normalize.`,
    candidates,
    async () => {
      const applyResults = await normalizeFrontmatterPass(app, settings, files, false, plugin);
      const changed = applyResults.filter((r) => r.changed).length;
      new import_obsidian13.Notice(`Vault Forge: Normalized frontmatter in ${changed} file(s).`, 4e3);
    }
  ).open();
}
var DEFAULT_LOWERCASE_FIELDS = [];
async function normalizeFrontmatterPass(app, settings, files, dryRun, plugin) {
  const paths = getVaultPaths(settings);
  const results = [];
  const enumFields = plugin.schemaCache ? plugin.schemaCache.getEnumFieldNames() : DEFAULT_LOWERCASE_FIELDS;
  const lowercaseFields = new Set(enumFields);
  for (const file of files) {
    const note = await readNote(app, file);
    if (!note || !note.hasFrontmatter)
      continue;
    const fm = note.frontmatter;
    let changed = false;
    const details = [];
    const upperKeys = Object.keys(fm).filter((k) => k !== k.toLowerCase());
    if (upperKeys.length > 0) {
      for (const key of upperKeys) {
        const lower = key.toLowerCase();
        if (lower !== key) {
          fm[lower] = fm[key];
          delete fm[key];
        }
      }
      changed = true;
      details.push(`${upperKeys.length} field name(s) lowercased`);
    }
    for (const field of lowercaseFields) {
      if (field in fm && typeof fm[field] === "string") {
        const original = fm[field];
        const lower = original.toLowerCase();
        if (original !== lower) {
          fm[field] = lower;
          changed = true;
          details.push(`${field} value lowercased`);
        }
      }
    }
    const tags = getTags(fm);
    const loweredTags = tags.map((t) => t.toLowerCase());
    const tagStr = tags.join("|");
    const loweredStr = loweredTags.join("|");
    if (tagStr !== loweredStr) {
      setTags(fm, loweredTags);
      changed = true;
      details.push("tags lowercased");
    }
    if (!changed)
      continue;
    if (!dryRun) {
      await backupNote(app, file, paths.patchBackups);
      await writeNote(app, note);
    }
    results.push({
      file: file.path,
      changed: true,
      detail: details.join(", ")
    });
  }
  return results;
}
var NormalizeConfirmModal = class extends import_obsidian13.Modal {
  constructor(app, plugin, title, summary, candidates, onConfirm) {
    super(app);
    this.plugin = plugin;
    this.title = title;
    this.summary = summary;
    this.candidates = candidates;
    this.onConfirm = onConfirm;
  }
  onOpen() {
    const { contentEl } = this;
    contentEl.empty();
    contentEl.createEl("h2", { text: this.title });
    contentEl.createEl("p", { text: this.summary });
    const list = contentEl.createEl("ul", { cls: "vault-forge-change-list" });
    for (const r of this.candidates.slice(0, 20)) {
      list.createEl("li", { text: `${r.file} \u2014 ${r.detail}` });
    }
    if (this.candidates.length > 20) {
      list.createEl("li", {
        text: `\u2026and ${this.candidates.length - 20} more`,
        cls: "vault-forge-more"
      });
    }
    if (this.plugin.settings.patchBackupEnabled) {
      contentEl.createEl("p", {
        text: "Backups will be written to System/VaultForge/Patches/Backups/",
        cls: "vault-forge-backup-notice"
      });
    }
    const buttonRow = contentEl.createDiv("vault-forge-button-row");
    const applyBtn = buttonRow.createEl("button", {
      text: "Apply",
      cls: "mod-cta"
    });
    applyBtn.addEventListener("click", async () => {
      this.close();
      await this.onConfirm();
    });
    const cancelBtn = buttonRow.createEl("button", { text: "Cancel" });
    cancelBtn.addEventListener("click", () => this.close());
  }
  onClose() {
    this.contentEl.empty();
  }
};

// src/commands/maintenance.ts
var import_obsidian14 = require("obsidian");
init_files();
async function runVaultMaintenance(plugin) {
  const { app, settings } = plugin;
  new import_obsidian14.Notice("Vault Forge: Running maintenance dry pass\u2026", 2e3);
  const dryResults = await runAllTasks(app, settings, true);
  const actions = dryResults.filter((r) => r.status === "removed" || r.status === "trimmed");
  if (actions.length === 0) {
    new import_obsidian14.Notice("Vault Forge: Nothing to clean up \u2014 vault is within retention policy.", 5e3);
    return;
  }
  new MaintenanceConfirmModal(app, plugin, dryResults, async () => {
    const applyResults = await runAllTasks(app, settings, false);
    const applied = applyResults.filter((r) => r.status === "removed" || r.status === "trimmed").length;
    const errors = applyResults.filter((r) => r.status === "error").length;
    if (errors > 0) {
      new import_obsidian14.Notice(`Vault Forge: Maintenance complete. ${applied} action(s), ${errors} error(s).`, 6e3);
    } else {
      new import_obsidian14.Notice(`Vault Forge: Maintenance complete. ${applied} item(s) cleaned up.`, 5e3);
    }
  }).open();
}
async function runAllTasks(app, settings, dryRun) {
  const results = [];
  results.push(...await trimLintHistory(app, settings, dryRun));
  results.push(...await trimLintRunNotes(app, settings, dryRun));
  results.push(...await trimPatchReportNotes(app, settings, dryRun));
  results.push(...await cleanPatchBackups(app, settings, dryRun));
  results.push(...await cleanInbox(app, settings, dryRun));
  return results;
}
async function trimLintHistory(app, settings, dryRun) {
  const paths = getVaultPaths(settings);
  const histFile = app.vault.getAbstractFileByPath(paths.lintHistoryJson);
  if (!(histFile instanceof import_obsidian14.TFile)) {
    return [{ task: "lint_history", target: paths.lintHistoryJson, status: "skipped", detail: "lint-history.json does not exist yet" }];
  }
  let history = [];
  try {
    const raw = await app.vault.read(histFile);
    history = JSON.parse(raw);
    if (!Array.isArray(history))
      history = [];
  } catch (e) {
    return [{ task: "lint_history", target: paths.lintHistoryJson, status: "error", detail: "Could not parse lint-history.json" }];
  }
  const before = history.length;
  const cutoff = /* @__PURE__ */ new Date();
  cutoff.setDate(cutoff.getDate() - settings.lintHistoryRetentionDays);
  history = history.filter((e) => {
    try {
      return new Date(e.timestamp) >= cutoff;
    } catch (e2) {
      return false;
    }
  });
  if (history.length > settings.lintHistoryMaxEntries) {
    history = history.slice(history.length - settings.lintHistoryMaxEntries);
  }
  const removed = before - history.length;
  if (removed === 0) {
    return [{
      task: "lint_history",
      target: paths.lintHistoryJson,
      status: "skipped",
      detail: `${before} entries, none exceed retention (${settings.lintHistoryRetentionDays} days / ${settings.lintHistoryMaxEntries} max)`
    }];
  }
  if (!dryRun) {
    await app.vault.modify(histFile, JSON.stringify(history, null, 2));
  }
  return [{
    task: "lint_history",
    target: paths.lintHistoryJson,
    status: "trimmed",
    detail: `Removed ${removed} entries (${before} \u2192 ${history.length}). Policy: ${settings.lintHistoryRetentionDays} days / ${settings.lintHistoryMaxEntries} max`
  }];
}
async function trimLintRunNotes(app, settings, dryRun) {
  const paths = getVaultPaths(settings);
  const files = getMarkdownFiles(app, paths.lintRuns).sort((a, b) => a.name.localeCompare(b.name));
  if (files.length <= settings.lintRunRetentionCount) {
    return [{
      task: "lint_runs",
      target: paths.lintRuns,
      status: "skipped",
      detail: `${files.length} lint report notes, within retention limit of ${settings.lintRunRetentionCount}`
    }];
  }
  const toRemove = files.slice(0, files.length - settings.lintRunRetentionCount);
  const results = [];
  for (const file of toRemove) {
    if (!dryRun) {
      await app.vault.delete(file);
    }
    results.push({
      task: "lint_runs",
      target: file.path,
      status: "removed",
      detail: `Lint report note over retention limit of ${settings.lintRunRetentionCount}`
    });
  }
  return results;
}
async function trimPatchReportNotes(app, settings, dryRun) {
  const paths = getVaultPaths(settings);
  const files = getMarkdownFiles(app, paths.patchReports).filter((f) => f.name.includes("-patch-report-")).sort((a, b) => a.name.localeCompare(b.name));
  if (files.length <= settings.patchReportRetentionCount) {
    return [{
      task: "patch_reports",
      target: paths.patchReports,
      status: "skipped",
      detail: `${files.length} patch report notes, within retention limit of ${settings.patchReportRetentionCount}`
    }];
  }
  const toRemove = files.slice(0, files.length - settings.patchReportRetentionCount);
  const results = [];
  for (const file of toRemove) {
    if (!dryRun) {
      await app.vault.delete(file);
    }
    results.push({
      task: "patch_reports",
      target: file.path,
      status: "removed",
      detail: `Patch report over retention limit of ${settings.patchReportRetentionCount}`
    });
  }
  return results;
}
async function cleanPatchBackups(app, settings, dryRun) {
  const paths = getVaultPaths(settings);
  const cutoff = Date.now() - settings.backupRetentionDays * 24 * 60 * 60 * 1e3;
  const results = [];
  const backupFolder = app.vault.getAbstractFileByPath(paths.patchBackups);
  if (!(backupFolder instanceof import_obsidian14.TFolder)) {
    return [{ task: "patch_backups", target: paths.patchBackups, status: "skipped", detail: "Backup folder does not exist yet" }];
  }
  const allFiles = app.vault.getFiles().filter(
    (f) => f.path.startsWith(paths.patchBackups) && f.name.endsWith(".bak")
  );
  const stale = allFiles.filter((f) => f.stat.mtime < cutoff);
  if (stale.length === 0) {
    return [{
      task: "patch_backups",
      target: paths.patchBackups,
      status: "skipped",
      detail: `No backup files older than ${settings.backupRetentionDays} days`
    }];
  }
  for (const file of stale) {
    if (!dryRun) {
      await app.vault.delete(file);
    }
    const age = Math.floor((Date.now() - file.stat.mtime) / (1e3 * 60 * 60 * 24));
    results.push({
      task: "patch_backups",
      target: file.path,
      status: "removed",
      detail: `Backup ${age} days old (threshold: ${settings.backupRetentionDays} days)`
    });
  }
  return results;
}
async function cleanInbox(app, settings, dryRun) {
  const paths = getVaultPaths(settings);
  const cutoff = Date.now() - settings.inboxRetentionDays * 24 * 60 * 60 * 1e3;
  const results = [];
  const inboxFolder = app.vault.getAbstractFileByPath(paths.inbox);
  if (!(inboxFolder instanceof import_obsidian14.TFolder)) {
    return [{ task: "inbox", target: paths.inbox, status: "skipped", detail: "Inbox folder does not exist" }];
  }
  const staleFiles = app.vault.getFiles().filter(
    (f) => f.path.startsWith(paths.inbox + "/") && f.stat.mtime < cutoff
  );
  if (staleFiles.length === 0) {
    return [{
      task: "inbox",
      target: paths.inbox,
      status: "skipped",
      detail: `No inbox files older than ${settings.inboxRetentionDays} days`
    }];
  }
  for (const file of staleFiles) {
    if (!dryRun) {
      await app.vault.delete(file);
    }
    const age = Math.floor((Date.now() - file.stat.mtime) / (1e3 * 60 * 60 * 24));
    results.push({
      task: "inbox",
      target: file.path,
      status: "removed",
      detail: `Inbox file ${age} days old (threshold: ${settings.inboxRetentionDays} days)`
    });
  }
  return results;
}
var MaintenanceConfirmModal = class extends import_obsidian14.Modal {
  constructor(app, plugin, results, onConfirm) {
    super(app);
    this.plugin = plugin;
    this.results = results;
    this.onConfirm = onConfirm;
  }
  onOpen() {
    const { contentEl } = this;
    contentEl.empty();
    const actions = this.results.filter((r) => r.status === "removed" || r.status === "trimmed");
    const errors = this.results.filter((r) => r.status === "error");
    const { settings } = this.plugin;
    contentEl.createEl("h2", { text: "Vault Maintenance" });
    const policy = contentEl.createDiv("vault-forge-maintenance-policy");
    policy.createEl("p", { text: `Retention policy:`, cls: "vault-forge-policy-label" });
    const policyList = policy.createEl("ul");
    policyList.createEl("li", { text: `Lint history: ${settings.lintHistoryRetentionDays} days / ${settings.lintHistoryMaxEntries} entries max` });
    policyList.createEl("li", { text: `Lint run notes: ${settings.lintRunRetentionCount} notes max` });
    policyList.createEl("li", { text: `Patch reports: ${settings.patchReportRetentionCount} notes max` });
    policyList.createEl("li", { text: `Patch backups: ${settings.backupRetentionDays} days` });
    policyList.createEl("li", { text: `Inbox files: ${settings.inboxRetentionDays} days` });
    if (errors.length > 0) {
      contentEl.createEl("h3", { text: "Errors" });
      const list2 = contentEl.createEl("ul", { cls: "vault-forge-error-list" });
      for (const r of errors) {
        list2.createEl("li", { text: `[${r.task}] ${r.target} \u2014 ${r.detail}` });
      }
    }
    contentEl.createEl("h3", { text: `${actions.length} item(s) to clean up` });
    const list = contentEl.createEl("ul", { cls: "vault-forge-change-list" });
    for (const r of actions.slice(0, 20)) {
      list.createEl("li", { text: `[${r.task}] ${r.target} \u2014 ${r.detail}` });
    }
    if (actions.length > 20) {
      list.createEl("li", { text: `\u2026and ${actions.length - 20} more`, cls: "vault-forge-more" });
    }
    const buttonRow = contentEl.createDiv("vault-forge-button-row");
    const applyBtn = buttonRow.createEl("button", { text: "Apply", cls: "mod-cta" });
    applyBtn.addEventListener("click", async () => {
      this.close();
      await this.onConfirm();
    });
    const cancelBtn = buttonRow.createEl("button", { text: "Cancel" });
    cancelBtn.addEventListener("click", () => this.close());
  }
  onClose() {
    this.contentEl.empty();
  }
};

// src/commands/restore-patch.ts
var import_obsidian15 = require("obsidian");
async function runRestorePatch(plugin) {
  const { app, settings } = plugin;
  const paths = getVaultPaths(settings);
  const manifestFiles = app.vault.getFiles().filter(
    (f) => f.path.startsWith(paths.patchReports) && f.name.endsWith("-patch-manifest.json")
  ).sort((a, b) => b.name.localeCompare(a.name));
  if (manifestFiles.length === 0) {
    new import_obsidian15.Notice("Vault Forge: No patch manifests found. Apply a patch with backups enabled first.", 6e3);
    return;
  }
  const manifests = [];
  for (const file of manifestFiles) {
    try {
      const raw = await app.vault.read(file);
      manifests.push(JSON.parse(raw));
    } catch (e) {
    }
  }
  if (manifests.length === 0) {
    new import_obsidian15.Notice("Vault Forge: Could not read any patch manifests.", 5e3);
    return;
  }
  new RestorePatchModal(app, plugin, manifests).open();
}
var RestorePatchModal = class extends import_obsidian15.Modal {
  constructor(app, plugin, manifests) {
    super(app);
    this.selected = null;
    this.plugin = plugin;
    this.manifests = manifests;
  }
  onOpen() {
    this.renderList();
  }
  renderList() {
    const { contentEl } = this;
    contentEl.empty();
    contentEl.createEl("h2", { text: "Restore Patch Run" });
    contentEl.createEl("p", {
      text: "Select a patch run to restore. All files changed by that patch will be replaced with their backups.",
      cls: "setting-item-description"
    });
    const list = contentEl.createDiv("vault-forge-restore-list");
    for (const manifest of this.manifests) {
      const item = list.createDiv("vault-forge-restore-item");
      item.addEventListener("click", () => {
        this.selected = manifest;
        this.renderConfirm();
      });
      const date = new Date(manifest.applied_at).toLocaleString();
      item.createEl("div", { text: manifest.description || manifest.run_id, cls: "vault-forge-restore-title" });
      item.createEl("div", { text: `${date} \u2014 ${manifest.changes.length} file(s)`, cls: "vault-forge-restore-meta" });
    }
    const closeBtn = contentEl.createEl("button", { text: "Cancel" });
    closeBtn.addEventListener("click", () => this.close());
  }
  renderConfirm() {
    const { contentEl } = this;
    const manifest = this.selected;
    contentEl.empty();
    contentEl.createEl("h2", { text: "Confirm Restore" });
    contentEl.createEl("p", {
      text: manifest.description || manifest.run_id,
      cls: "vault-forge-patch-description"
    });
    contentEl.createEl("p", {
      text: `Applied: ${new Date(manifest.applied_at).toLocaleString()}`,
      cls: "setting-item-description"
    });
    contentEl.createEl("h3", { text: `${manifest.changes.length} file(s) will be restored` });
    const list = contentEl.createEl("ul", { cls: "vault-forge-change-list" });
    for (const change of manifest.changes.slice(0, 20)) {
      list.createEl("li", { text: change.file });
    }
    if (manifest.changes.length > 20) {
      list.createEl("li", { text: `\u2026and ${manifest.changes.length - 20} more`, cls: "vault-forge-more" });
    }
    contentEl.createEl("p", {
      text: "This will overwrite the current versions of these files with their pre-patch backups. This cannot be undone.",
      cls: "vault-forge-error-note"
    });
    const buttonRow = contentEl.createDiv("vault-forge-button-row");
    const restoreBtn = buttonRow.createEl("button", { text: "Restore", cls: "mod-cta mod-warning" });
    restoreBtn.addEventListener("click", async () => {
      this.close();
      await this.applyRestore(manifest);
    });
    const backBtn = buttonRow.createEl("button", { text: "Back" });
    backBtn.addEventListener("click", () => this.renderList());
    const cancelBtn = buttonRow.createEl("button", { text: "Cancel" });
    cancelBtn.addEventListener("click", () => this.close());
  }
  async applyRestore(manifest) {
    const { app } = this;
    let restored = 0;
    let failed = 0;
    for (const change of manifest.changes) {
      const backupFile = app.vault.getAbstractFileByPath(change.backup);
      if (!(backupFile instanceof import_obsidian15.TFile)) {
        console.warn(`[VaultForge] Backup not found: ${change.backup}`);
        failed++;
        continue;
      }
      try {
        const backupContent = await app.vault.read(backupFile);
        const targetFile = app.vault.getAbstractFileByPath(change.file);
        if (targetFile instanceof import_obsidian15.TFile) {
          await app.vault.modify(targetFile, backupContent);
        } else {
          await app.vault.create(change.file, backupContent);
        }
        restored++;
      } catch (e) {
        console.warn(`[VaultForge] Could not restore ${change.file}:`, e);
        failed++;
      }
    }
    if (failed > 0) {
      new import_obsidian15.Notice(`Vault Forge: Restored ${restored} file(s). ${failed} backup(s) not found.`, 7e3);
    } else {
      new import_obsidian15.Notice(`Vault Forge: Restored ${restored} file(s) from patch run.`, 5e3);
    }
  }
  onClose() {
    this.contentEl.empty();
  }
};

// src/commands/utilities.ts
var import_obsidian16 = require("obsidian");
init_files();
async function runRenameDataviewFolder(plugin) {
  new RenameDataviewModal(plugin.app, plugin).open();
}
var RenameDataviewModal = class extends import_obsidian16.Modal {
  constructor(app, plugin) {
    super(app);
    this.currentFolder = "";
    this.newFolder = "";
    this.scanScope = "";
    this.plugin = plugin;
  }
  onOpen() {
    const { contentEl } = this;
    contentEl.empty();
    contentEl.createEl("h2", { text: "Rename Dataview Folder" });
    contentEl.createEl("p", {
      text: "Updates folder path references inside dataview blocks only. Lines outside dataview blocks are never touched.",
      cls: "setting-item-description"
    });
    new import_obsidian16.Setting(contentEl).setName("Current folder path").setDesc("The folder path currently referenced in dataview queries.").addText((t) => {
      t.setPlaceholder("Work/Skills");
      t.onChange((val) => {
        this.currentFolder = val.trim().replace(/^["']+|["']+$/g, "").replace(/\/+$/, "");
      });
    });
    new import_obsidian16.Setting(contentEl).setName("New folder path").setDesc("The replacement folder path.").addText((t) => {
      t.setPlaceholder("Work/Disciplines");
      t.onChange((val) => {
        this.newFolder = val.trim().replace(/^["']+|["']+$/g, "").replace(/\/+$/, "");
      });
    });
    new import_obsidian16.Setting(contentEl).setName("Scope (optional)").setDesc("Limit scanning to a subfolder. Leave empty to scan the entire vault.").addText((t) => {
      t.setPlaceholder("Work");
      t.onChange((val) => {
        this.scanScope = val.trim();
      });
    });
    const buttonRow = contentEl.createDiv("vault-forge-button-row");
    const previewBtn = buttonRow.createEl("button", { text: "Preview", cls: "mod-cta" });
    previewBtn.addEventListener("click", async () => {
      if (!this.currentFolder || !this.newFolder) {
        new import_obsidian16.Notice("Vault Forge: Both folder paths are required.", 3e3);
        return;
      }
      if (this.currentFolder === this.newFolder) {
        new import_obsidian16.Notice("Vault Forge: Current and new folder paths are the same.", 3e3);
        return;
      }
      this.close();
      await this.runRename(true);
    });
    const cancelBtn = buttonRow.createEl("button", { text: "Cancel" });
    cancelBtn.addEventListener("click", () => this.close());
  }
  async runRename(dryRun) {
    const { app, plugin } = this;
    const paths = getVaultPaths(plugin.settings);
    const files = getMarkdownFiles(
      app,
      this.scanScope || void 0
    ).filter((f) => !f.path.startsWith(paths.vaultForge));
    const candidates = [];
    for (const file of files) {
      const content = await app.vault.read(file);
      if (!/(?:```|~~~)dataview/.test(content))
        continue;
      const updated = updateDataviewFolderRefs(content, this.currentFolder, this.newFolder);
      if (updated !== content) {
        candidates.push({ file, updated });
      }
    }
    if (candidates.length === 0) {
      new import_obsidian16.Notice(
        `Vault Forge: No dataview references to "${this.currentFolder}" found.`,
        4e3
      );
      return;
    }
    new DataviewRenameConfirmModal(
      app,
      plugin,
      this.currentFolder,
      this.newFolder,
      candidates
    ).open();
  }
  onClose() {
    this.contentEl.empty();
  }
};
function updateDataviewFolderRefs(content, current, newFolder) {
  const lines = content.split("\n");
  const result = [];
  let inDataview = false;
  for (const line of lines) {
    const trimmed = line.trimEnd();
    if (/^(?:```|~~~)dataview\s*$/.test(trimmed)) {
      inDataview = true;
      result.push(line);
      continue;
    }
    if (inDataview && /^(?:```|~~~)\s*$/.test(trimmed)) {
      inDataview = false;
      result.push(line);
      continue;
    }
    if (inDataview) {
      result.push(line.split(current).join(newFolder));
    } else {
      result.push(line);
    }
  }
  return result.join("\n");
}
var DataviewRenameConfirmModal = class extends import_obsidian16.Modal {
  constructor(app, plugin, currentFolder, newFolder, candidates) {
    super(app);
    this.plugin = plugin;
    this.currentFolder = currentFolder;
    this.newFolder = newFolder;
    this.candidates = candidates;
  }
  onOpen() {
    const { contentEl } = this;
    contentEl.empty();
    contentEl.createEl("h2", { text: "Rename Dataview Folder \u2014 Confirm" });
    contentEl.createEl("p", {
      text: `"${this.currentFolder}" \u2192 "${this.newFolder}"`,
      cls: "vault-forge-patch-description"
    });
    contentEl.createEl("p", {
      text: `${this.candidates.length} file(s) will be updated.`
    });
    const list = contentEl.createEl("ul", { cls: "vault-forge-change-list" });
    for (const { file } of this.candidates.slice(0, 20)) {
      list.createEl("li", { text: file.path });
    }
    if (this.candidates.length > 20) {
      list.createEl("li", {
        text: `\u2026and ${this.candidates.length - 20} more`,
        cls: "vault-forge-more"
      });
    }
    if (this.plugin.settings.patchBackupEnabled) {
      contentEl.createEl("p", {
        text: "Backups will be written to System/VaultForge/Patches/Backups/",
        cls: "vault-forge-backup-notice"
      });
    }
    const buttonRow = contentEl.createDiv("vault-forge-button-row");
    const applyBtn = buttonRow.createEl("button", { text: "Apply", cls: "mod-cta" });
    applyBtn.addEventListener("click", async () => {
      this.close();
      const paths = getVaultPaths(this.plugin.settings);
      let changed = 0;
      for (const { file, updated } of this.candidates) {
        if (this.plugin.settings.patchBackupEnabled) {
          const { backupNote: backupNote2 } = await Promise.resolve().then(() => (init_frontmatter(), frontmatter_exports));
          await backupNote2(this.app, file, paths.patchBackups);
        }
        await this.app.vault.modify(file, updated);
        changed++;
      }
      new import_obsidian16.Notice(
        `Vault Forge: Updated dataview references in ${changed} file(s).`,
        4e3
      );
    });
    const cancelBtn = buttonRow.createEl("button", { text: "Cancel" });
    cancelBtn.addEventListener("click", () => this.close());
  }
  onClose() {
    this.contentEl.empty();
  }
};

// src/main.ts
var VaultForgePlugin = class extends import_obsidian17.Plugin {
  async onload() {
    await this.loadSettings();
    this.schemaCache = new SchemaCache(this.app, this.settings);
    this.addCommand({
      id: "apply-vault-patch",
      name: "Apply Vault Patch",
      callback: () => {
        runApplyPatch(this).catch((e) => {
          var _a;
          new import_obsidian17.Notice(`Vault Forge: ${(_a = e == null ? void 0 : e.message) != null ? _a : "Unexpected error"}`, 6e3);
          console.error("[VaultForge] apply-vault-patch error:", e);
        });
      }
    });
    this.addCommand({
      id: "run-vault-lint",
      name: "Run Vault Lint",
      callback: () => {
        runVaultLint(this).catch((e) => {
          var _a;
          new import_obsidian17.Notice(`Vault Forge: ${(_a = e == null ? void 0 : e.message) != null ? _a : "Unexpected error"}`, 6e3);
          console.error("[VaultForge] run-vault-lint error:", e);
        });
      }
    });
    this.addCommand({
      id: "validate-schema",
      name: "Validate Schema",
      callback: () => {
        runValidateSchema(this).catch((e) => {
          var _a;
          new import_obsidian17.Notice(`Vault Forge: ${(_a = e == null ? void 0 : e.message) != null ? _a : "Unexpected error"}`, 6e3);
          console.error("[VaultForge] validate-schema error:", e);
        });
      }
    });
    this.addCommand({
      id: "normalize-tags",
      name: "Normalize Tags",
      callback: () => {
        runNormalizeTags(this).catch((e) => {
          var _a;
          new import_obsidian17.Notice(`Vault Forge: ${(_a = e == null ? void 0 : e.message) != null ? _a : "Unexpected error"}`, 6e3);
          console.error("[VaultForge] normalize-tags error:", e);
        });
      }
    });
    this.addCommand({
      id: "normalize-frontmatter",
      name: "Normalize Frontmatter",
      callback: () => {
        runNormalizeFrontmatter(this).catch((e) => {
          var _a;
          new import_obsidian17.Notice(`Vault Forge: ${(_a = e == null ? void 0 : e.message) != null ? _a : "Unexpected error"}`, 6e3);
          console.error("[VaultForge] normalize-frontmatter error:", e);
        });
      }
    });
    this.addCommand({
      id: "vault-maintenance",
      name: "Vault Maintenance",
      callback: () => {
        runVaultMaintenance(this).catch((e) => {
          var _a;
          new import_obsidian17.Notice(`Vault Forge: ${(_a = e == null ? void 0 : e.message) != null ? _a : "Unexpected error"}`, 6e3);
          console.error("[VaultForge] vault-maintenance error:", e);
        });
      }
    });
    this.addCommand({
      id: "vault-repair",
      name: "Vault Repair",
      callback: () => {
        runVaultRepair(this).catch((e) => {
          var _a;
          new import_obsidian17.Notice(`Vault Forge: ${(_a = e == null ? void 0 : e.message) != null ? _a : "Unexpected error"}`, 6e3);
          console.error("[VaultForge] vault-repair error:", e);
        });
      }
    });
    this.addCommand({
      id: "restore-patch-run",
      name: "Restore Patch Run",
      callback: () => {
        runRestorePatch(this).catch((e) => {
          var _a;
          new import_obsidian17.Notice(`Vault Forge: ${(_a = e == null ? void 0 : e.message) != null ? _a : "Unexpected error"}`, 6e3);
          console.error("[VaultForge] restore-patch-run error:", e);
        });
      }
    });
    this.addCommand({
      id: "rename-dataview-folder",
      name: "Rename Dataview Folder",
      callback: () => {
        runRenameDataviewFolder(this).catch((e) => {
          var _a;
          new import_obsidian17.Notice(`Vault Forge: ${(_a = e == null ? void 0 : e.message) != null ? _a : "Unexpected error"}`, 6e3);
          console.error("[VaultForge] rename-dataview-folder error:", e);
        });
      }
    });
    this.addCommand({
      id: "install-documentation",
      name: "Install Documentation",
      callback: () => {
        installVaultForgeDocumentation(this.app, this.settings).catch((e) => {
          var _a;
          new import_obsidian17.Notice(`Vault Forge: ${(_a = e == null ? void 0 : e.message) != null ? _a : "Unexpected error"}`, 6e3);
          console.error("[VaultForge] install-documentation error:", e);
        });
      }
    });
    this.addSettingTab(new VaultForgeSettingsTab(this.app, this));
    this.app.workspace.onLayoutReady(() => {
      this.schemaCache.refresh().catch(() => {
        setTimeout(() => this.schemaCache.refresh().catch((e) => {
          console.warn("[VaultForge] Schema cache retry failed:", e);
        }), 3e3);
      });
    });
    console.log("Vault Forge loaded");
  }
  onunload() {
    console.log("Vault Forge unloaded");
  }
  async loadSettings() {
    var _a;
    const loaded = (_a = await this.loadData()) != null ? _a : {};
    this.settings = Object.assign({}, DEFAULT_SETTINGS, loaded);
    if (!loaded.patchDefaultFile || loaded.patchDefaultFile === "System/Exports/vault-patch.yaml") {
      this.settings.patchDefaultFile = DEFAULT_SETTINGS.patchDefaultFile;
    }
  }
  async saveSettings() {
    await this.saveData(this.settings);
    if (this.schemaCache) {
      this.schemaCache.updateSettings(this.settings);
    }
  }
};
